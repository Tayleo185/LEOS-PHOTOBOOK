-- Additive appointment storage; original bookkeeping tables and buckets are untouched.
create extension if not exists btree_gist with schema extensions;
set search_path=public,extensions;
create table public.leos_booking_settings(
 company_id uuid primary key references public.leos_companies(id),
 slug text not null unique check(slug ~ '^[a-z0-9-]{8,70}$'),
 enabled boolean not null default false,
 display_name text not null check(length(display_name) between 2 and 90),
 timezone text not null default 'America/Chicago',
 lead_minutes integer not null default 120 check(lead_minutes between 0 and 10080),
 cancel_hours integer not null default 24 check(cancel_hours between 0 and 168),
 horizon_days integer not null default 60 check(horizon_days between 1 and 90),
 instructions text not null default '' check(length(instructions)<=1000)
);
create table public.leos_booking_services(
 id uuid primary key default gen_random_uuid(),company_id uuid not null references public.leos_companies(id),
 name text not null check(length(name) between 2 and 100),
 duration integer not null check(duration between 15 and 480 and duration%15=0),
 buffer integer not null default 0 check(buffer between 0 and 120 and buffer%15=0),
 price numeric(12,2) not null default 0 check(price>=0),onsite boolean not null default false,active boolean not null default true,
 unique(company_id,id)
);
create table public.leos_booking_resources(
 id uuid primary key default gen_random_uuid(),company_id uuid not null references public.leos_companies(id),
 name text not null check(length(name) between 2 and 80),active boolean not null default true,
 hours jsonb not null default '{}'::jsonb,unique(company_id,id)
);
create table public.leos_booking_blocks(
 id uuid primary key default gen_random_uuid(),company_id uuid not null,resource_id uuid not null,
 starts_at timestamptz not null,ends_at timestamptz not null,check(ends_at>starts_at),
 foreign key(company_id,resource_id) references public.leos_booking_resources(company_id,id)
);
create table public.leos_appointments(
 id uuid primary key,company_id uuid not null,resource_id uuid not null,service_id uuid not null,
 customer_id uuid not null references auth.users(id),customer_name text not null check(length(customer_name) between 2 and 100),
 email text not null,phone text not null check(length(phone) between 7 and 40),address text not null default '' check(length(address)<=400),
 starts_at timestamptz not null,ends_at timestamptz not null,occupied tstzrange not null,
 status text not null default 'confirmed' check(status in ('confirmed','cancelled','completed','no_show')),
 service_name text not null,resource_name text not null,price numeric(12,2) not null,
 created_at timestamptz not null default now(),updated_at timestamptz not null default now(),
 foreign key(company_id,resource_id) references public.leos_booking_resources(company_id,id),
 foreign key(company_id,service_id) references public.leos_booking_services(company_id,id),
 check(ends_at>starts_at and lower(occupied)=starts_at and upper(occupied)>=ends_at and not isempty(occupied)),
 exclude using gist(resource_id with =, occupied with &&) where(status<>'cancelled')
);
create index leos_appt_customer on public.leos_appointments(customer_id,starts_at);
create index leos_appt_company on public.leos_appointments(company_id,starts_at);
create index leos_booking_services_company on public.leos_booking_services(company_id);
create index leos_booking_resources_company on public.leos_booking_resources(company_id);
create index leos_booking_blocks_company on public.leos_booking_blocks(company_id,resource_id,starts_at);
alter table public.leos_booking_settings enable row level security;
alter table public.leos_booking_services enable row level security;
alter table public.leos_booking_resources enable row level security;
alter table public.leos_booking_blocks enable row level security;
alter table public.leos_appointments enable row level security;
revoke all on public.leos_booking_settings,public.leos_booking_services,public.leos_booking_resources,public.leos_booking_blocks,public.leos_appointments from anon,authenticated;
grant all on public.leos_booking_settings,public.leos_booking_services,public.leos_booking_resources,public.leos_booking_blocks,public.leos_appointments to service_role;
reset search_path;

-- Service-only functions. The Edge API verifies identity and company role first.
create function public.leos_booking_slots(p_company uuid,p_service uuid,p_resource uuid,p_day date,p_ignore uuid default null)
returns table(starts_at timestamptz,ends_at timestamptz) language sql stable security invoker set search_path='' as $$
 with config as (
 select c.*,s.duration,s.buffer,r.hours from public.leos_booking_settings c
 join public.leos_companies co on co.id=c.company_id and not co.suspended and co.subscription_status in ('preview','active','trialing')
 join public.leos_booking_services s on s.company_id=c.company_id and s.id=p_service and s.active
 join public.leos_booking_resources r on r.company_id=c.company_id and r.id=p_resource and r.active
 where c.company_id=p_company and c.enabled
 and p_day >= (now() at time zone c.timezone)::date and p_day <= (now() at time zone c.timezone)::date+c.horizon_days
 ), candidates as (
 select cfg.*,g as t,g+make_interval(mins=>duration) as e,g+make_interval(mins=>duration+buffer) as occupied_end
 from config cfg cross join lateral generate_series(p_day::timestamp at time zone timezone, ((p_day+1)::timestamp at time zone timezone)-interval '15 minutes', interval '15 minutes') g
 )
 select t,e from candidates x where t>=now()+make_interval(mins=>lead_minutes)
 and (t at time zone timezone)::date=p_day
 and exists(select 1 from jsonb_array_elements(coalesce(hours->(extract(dow from p_day)::integer::text),'[]'::jsonb)) w
 where (t at time zone timezone)::time >= (w->>0)::time
 and (occupied_end at time zone timezone)::date=p_day and (occupied_end at time zone timezone)::time <= (w->>1)::time)
 and not exists(select 1 from public.leos_appointments a where a.resource_id=p_resource and a.status<>'cancelled' and (p_ignore is null or a.id<>p_ignore) and a.occupied && tstzrange(t,occupied_end,'[)'))
 and not exists(select 1 from public.leos_booking_blocks b where b.resource_id=p_resource and tstzrange(b.starts_at,b.ends_at,'[)') && tstzrange(t,occupied_end,'[)'))
 order by t;
$$;
revoke all on function public.leos_booking_slots(uuid,uuid,uuid,date,uuid) from public,anon,authenticated;
grant execute on function public.leos_booking_slots(uuid,uuid,uuid,date,uuid) to service_role;

create function public.leos_book_appointment(p_company uuid,p_service uuid,p_resource uuid,p_start timestamptz,p_customer uuid,p_name text,p_email text,p_phone text,p_address text,p_id uuid,p_reschedule uuid default null)
returns uuid language plpgsql security invoker set search_path='' as $$
declare cfg public.leos_booking_settings; svc public.leos_booking_services; res public.leos_booking_resources; old public.leos_appointments; finish timestamptz;
begin
 perform 1 from public.leos_companies where id=p_company for update;
 select * into cfg from public.leos_booking_settings where company_id=p_company;
 if not found or not cfg.enabled then raise exception 'Booking is unavailable'; end if;
 if p_reschedule is not null then
  select * into old from public.leos_appointments where id=p_reschedule and company_id=p_company and customer_id=p_customer for update;
  if not found or old.status<>'confirmed' or old.starts_at<=now()+make_interval(hours=>cfg.cancel_hours) then raise exception 'This appointment cannot be rescheduled online'; end if;
 else
  select * into old from public.leos_appointments where id=p_id;
  if found then
   if old.customer_id=p_customer and old.company_id=p_company and old.service_id=p_service and old.resource_id=p_resource and old.starts_at=p_start and old.status='confirmed' then return old.id; end if;
   raise exception 'Invalid booking reference';
  end if;
 end if;
 if (select count(*) from public.leos_appointments where customer_id=p_customer and company_id=p_company and created_at>now()-interval '1 hour')>=10 then raise exception 'Too many bookings. Contact the business'; end if;
 select * into svc from public.leos_booking_services where id=p_service and company_id=p_company and active;
 if not found then raise exception 'Service unavailable'; end if;
 select * into res from public.leos_booking_resources where id=p_resource and company_id=p_company and active;
 if not found then raise exception 'Staff unavailable'; end if;
 if svc.onsite and length(trim(p_address))<7 then raise exception 'Enter the service address'; end if;
 select ends_at into finish from public.leos_booking_slots(p_company,p_service,p_resource,(p_start at time zone cfg.timezone)::date,p_reschedule) where starts_at=p_start;
 if finish is null then raise exception 'That time is no longer available. Choose another slot'; end if;
 if p_reschedule is not null then
  update public.leos_appointments set service_id=svc.id,resource_id=res.id,service_name=svc.name,resource_name=res.name,price=svc.price,
  starts_at=p_start,ends_at=finish,occupied=tstzrange(p_start,finish+make_interval(mins=>svc.buffer),'[)'),updated_at=now() where id=p_reschedule;
  return p_reschedule;
 end if;
 insert into public.leos_appointments(id,company_id,service_id,resource_id,customer_id,customer_name,email,phone,address,starts_at,ends_at,occupied,service_name,resource_name,price)
 values(p_id,p_company,svc.id,res.id,p_customer,trim(p_name),p_email,trim(p_phone),trim(p_address),p_start,finish,tstzrange(p_start,finish+make_interval(mins=>svc.buffer),'[)'),svc.name,res.name,svc.price);
 return p_id;
end $$;
revoke all on function public.leos_book_appointment(uuid,uuid,uuid,timestamptz,uuid,text,text,text,text,uuid,uuid) from public,anon,authenticated;
grant execute on function public.leos_book_appointment(uuid,uuid,uuid,timestamptz,uuid,text,text,text,text,uuid,uuid) to service_role;

create function public.leos_manage_booking(p_company uuid,p_actor uuid,p_action text,p jsonb)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare result jsonb; a public.leos_appointments; cfg public.leos_booking_settings; rid uuid;
begin
 perform 1 from public.leos_companies where id=p_company and not suspended and subscription_status in ('preview','active','trialing') for update;
 if not found then raise exception 'Company is read-only'; end if;
 if not exists(select 1 from public.leos_company_members where company_id=p_company and user_id=p_actor and role in ('owner','admin')) then raise exception 'Administrator access required'; end if;
 if p_action='settings' then
  if not exists(select 1 from pg_catalog.pg_timezone_names where name=p->>'timezone') then raise exception 'Invalid time zone'; end if;
  insert into public.leos_booking_settings(company_id,slug,enabled,display_name,timezone,lead_minutes,cancel_hours,horizon_days,instructions)
  values(p_company,'book-'||replace(p_company::text,'-',''),(p->>'enabled')::boolean,p->>'display_name',p->>'timezone',(p->>'lead_minutes')::integer,(p->>'cancel_hours')::integer,(p->>'horizon_days')::integer,p->>'instructions')
  on conflict(company_id) do update set enabled=excluded.enabled,display_name=excluded.display_name,timezone=excluded.timezone,lead_minutes=excluded.lead_minutes,cancel_hours=excluded.cancel_hours,horizon_days=excluded.horizon_days,instructions=excluded.instructions returning to_jsonb(leos_booking_settings.*) into result;
 elsif p_action='service' then
  rid=(p->>'id')::uuid;
  if exists(select 1 from public.leos_booking_services where id=rid and company_id<>p_company) then raise exception 'Service unavailable'; end if;
  insert into public.leos_booking_services(id,company_id,name,duration,buffer,price,onsite,active) values(rid,p_company,p->>'name',(p->>'duration')::integer,(p->>'buffer')::integer,(p->>'price')::numeric,(p->>'onsite')::boolean,(p->>'active')::boolean)
  on conflict(id) do update set name=excluded.name,duration=excluded.duration,buffer=excluded.buffer,price=excluded.price,onsite=excluded.onsite,active=excluded.active returning to_jsonb(leos_booking_services.*) into result;
 elsif p_action='resource' then
  rid=(p->>'id')::uuid;
  if exists(select 1 from public.leos_booking_resources where id=rid and company_id<>p_company) then raise exception 'Staff unavailable'; end if;
  insert into public.leos_booking_resources(id,company_id,name,hours,active) values(rid,p_company,p->>'name',p->'hours',(p->>'active')::boolean)
  on conflict(id) do update set name=excluded.name,hours=excluded.hours,active=excluded.active returning to_jsonb(leos_booking_resources.*) into result;
 elsif p_action='block' then
  if exists(select 1 from public.leos_appointments where company_id=p_company and resource_id=(p->>'resource_id')::uuid and status='confirmed' and occupied && tstzrange((p->>'starts_at')::timestamptz,(p->>'ends_at')::timestamptz,'[)')) then raise exception 'Time off overlaps a confirmed appointment. Resolve that booking first'; end if;
  insert into public.leos_booking_blocks(company_id,resource_id,starts_at,ends_at) values(p_company,(p->>'resource_id')::uuid,(p->>'starts_at')::timestamptz,(p->>'ends_at')::timestamptz) returning to_jsonb(leos_booking_blocks.*) into result;
 elsif p_action='unblock' then
  delete from public.leos_booking_blocks where id=(p->>'id')::uuid and company_id=p_company;
  result='{"ok":true}'::jsonb;
 elsif p_action='status' then
  if p->>'status' not in ('cancelled','completed','no_show') then raise exception 'Invalid status'; end if;
  select * into a from public.leos_appointments where id=(p->>'id')::uuid and company_id=p_company for update;
  if not found or a.status<>'confirmed' then raise exception 'Appointment is no longer confirmed'; end if;
  if p->>'status' in ('completed','no_show') and a.starts_at>now() then raise exception 'Cannot complete a future appointment'; end if;
  update public.leos_appointments set status=p->>'status',updated_at=now() where id=a.id;
  result='{"ok":true}'::jsonb;
 else raise exception 'Unsupported action'; end if;
 insert into public.leos_company_audit(company_id,actor_id,action,detail) values(p_company,p_actor,'booking.'||p_action,'{}'::jsonb);
 return result;
end $$;
revoke all on function public.leos_manage_booking(uuid,uuid,text,jsonb) from public,anon,authenticated;
grant execute on function public.leos_manage_booking(uuid,uuid,text,jsonb) to service_role;

create function public.leos_cancel_appointment(p_id uuid,p_customer uuid) returns boolean language plpgsql security invoker set search_path='' as $$
declare a public.leos_appointments; cfg public.leos_booking_settings;
begin
 select * into a from public.leos_appointments where id=p_id and customer_id=p_customer for update;
 if not found then raise exception 'Appointment unavailable'; end if;
 if a.status='cancelled' then return true; end if;
 select * into cfg from public.leos_booking_settings where company_id=a.company_id;
 if a.status<>'confirmed' or a.starts_at<=now()+make_interval(hours=>cfg.cancel_hours) then raise exception 'Online cancellation is closed. Contact the business'; end if;
 update public.leos_appointments set status='cancelled',updated_at=now() where id=p_id;
 return true;
end $$;
revoke all on function public.leos_cancel_appointment(uuid,uuid) from public,anon,authenticated;
grant execute on function public.leos_cancel_appointment(uuid,uuid) to service_role;
