import {createClient} from 'npm:@supabase/supabase-js@2.118.0';
import {fail,id,clean,customer,day} from './policy.mjs';
const db=createClient(Deno.env.get('SUPABASE_URL')!,JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')||'{}').default||Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
const checked=async(q:any)=>{const r=await q;if(r.error)throw r.error;return r.data;};
const allowed=new Set(['https://leos-photobooks.onrender.com','http://terminal.local:4173']);
export async function handler(req:Request){
 const origin=req.headers.get('Origin')||'';
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin',...(allowed.has(origin)?{'Access-Control-Allow-Origin':origin}:{}),'Access-Control-Allow-Headers':'authorization,apikey,content-type,x-client-info','Access-Control-Allow-Methods':'POST,OPTIONS'};
 const reply=(body:any,status=200)=>new Response(JSON.stringify(body),{status,headers});
 if(origin&&!allowed.has(origin))return reply({error:'Origin not allowed.'},403);
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(req.method!=='POST')return reply({error:'Use POST.'},405);
 try{
  const raw=await req.text();if(raw.length>20000)fail('Request too large.',413);const b=JSON.parse(raw);
  if(!b||typeof b!=='object'||Array.isArray(b))fail('Invalid request.');
  const action=b.action;
  const catalog=async()=>{
   if(typeof b.slug!=='string'||!/^[a-z0-9-]{8,70}$/.test(b.slug))fail('Business not found.',404);
   const cfg=await checked(db.from('leos_booking_settings').select('*').eq('slug',b.slug).eq('enabled',true).maybeSingle());if(!cfg)fail('Online booking is unavailable.',404);
   const company=await checked(db.from('leos_companies').select('suspended,subscription_status').eq('id',cfg.company_id).single());
   if(company.suspended||!['preview','active','trialing'].includes(company.subscription_status))fail('Online booking is unavailable.',404);return cfg;
  };
  if(action==='catalog'){
   const cfg=await catalog();
   const [services,staff]=await Promise.all([checked(db.from('leos_booking_services').select('id,name,duration,buffer,price,onsite').eq('company_id',cfg.company_id).eq('active',true).order('name')),checked(db.from('leos_booking_resources').select('id,name').eq('company_id',cfg.company_id).eq('active',true).order('name'))]);
   const {display_name,timezone,lead_minutes,cancel_hours,horizon_days,instructions,slug}=cfg;
   return reply({business:{display_name,timezone,lead_minutes,cancel_hours,horizon_days,instructions,slug},services,staff});
  }
  if(action==='slots'){
   const cfg=await catalog();return reply({slots:await checked(db.rpc('leos_booking_slots',{p_company:cfg.company_id,p_service:id(b.serviceId),p_resource:id(b.resourceId),p_day:day(b.day)})),timezone:cfg.timezone});
  }
  const token=(req.headers.get('Authorization')||'').replace(/^Bearer\s+/i,'');if(!token)fail('Sign in to continue.',401);
  const identity=await db.auth.getUser(token);const user=identity.data?.user;if(identity.error||!user)fail('Session expired. Sign in again.',401);if(!user.email_confirmed_at)fail('Verify your email before booking.',403);
  if(action==='mine'){const appointments=await checked(db.from('leos_appointments').select('id,company_id,service_id,resource_id,service_name,resource_name,price,starts_at,ends_at,status,customer_name,email,phone,address').eq('customer_id',user.id).gte('starts_at',new Date(Date.now()-90*86400000).toISOString()).order('starts_at').limit(200));const ids=[...new Set(appointments.map((a:any)=>a.company_id))];const businesses=ids.length?await checked(db.from('leos_booking_settings').select('company_id,display_name,slug,timezone,cancel_hours').in('company_id',ids)):[];return reply({appointments,businesses});}
  if(action==='cancel'){await checked(db.rpc('leos_cancel_appointment',{p_id:id(b.id),p_customer:user.id}));return reply({ok:true});}
  if(action==='book'||action==='reschedule'){
   const cfg=await catalog();const start=Date.parse(b.start);if(!Number.isFinite(start))fail('Choose an available time.');let c;
   if(action==='reschedule'){
    const old=await checked(db.from('leos_appointments').select('customer_name,phone,address').eq('id',id(b.id)).eq('company_id',cfg.company_id).eq('customer_id',user.id).maybeSingle());if(!old)fail('Appointment unavailable.',404);c={name:old.customer_name,phone:old.phone,address:old.address};
   }else c=customer(b);
   const result=await checked(db.rpc('leos_book_appointment',{p_company:cfg.company_id,p_service:id(b.serviceId),p_resource:id(b.resourceId),p_start:new Date(start).toISOString(),p_customer:user.id,p_name:c.name,p_email:user.email,p_phone:c.phone,p_address:c.address,p_id:id(b.newId||b.id),p_reschedule:action==='reschedule'?id(b.id):null}));
   return reply({id:result});
  }
  const cid=id(b.companyId);const member=await checked(db.from('leos_company_members').select('role').eq('company_id',cid).eq('user_id',user.id).maybeSingle());if(!member||!['owner','admin'].includes(member.role))fail('Company administrator access required.',403);
  if(action==='admin_state'){
   const [settings,services,staff,blocks,appointments]=await Promise.all([
    checked(db.from('leos_booking_settings').select('*').eq('company_id',cid).maybeSingle()),checked(db.from('leos_booking_services').select('*').eq('company_id',cid).order('name')),checked(db.from('leos_booking_resources').select('*').eq('company_id',cid).order('name')),checked(db.from('leos_booking_blocks').select('*').eq('company_id',cid).gte('ends_at',new Date().toISOString()).order('starts_at').limit(500)),checked(db.from('leos_appointments').select('*').eq('company_id',cid).gte('starts_at',new Date(Date.parse(day(b.day)+'T00:00:00Z')-86400000).toISOString()).lt('starts_at',new Date(Date.parse(day(b.day)+'T00:00:00Z')+3*86400000).toISOString()).order('starts_at').limit(1000))]);
   return reply({settings,services,staff,blocks,appointments,calendarLimit:appointments.length===1000});
  }
  if(action==='manage')return reply({result:await checked(db.rpc('leos_manage_booking',{p_company:cid,p_actor:user.id,p_action:b.kind,p:clean(b.kind,b.payload)}))});
  fail('Unknown request.');
 }catch(e:any){
  if(e.status)return reply({error:e.message},e.status);
  if(e.code==='23P01')return reply({error:'That time was just booked. Choose another slot.'},409);
  if(e.code==='P0001')return reply({error:e.message},409);
  if(e instanceof SyntaxError)return reply({error:'Invalid request.'},400);
  console.error('Booking request failed',e.code||'internal');return reply({error:'Booking could not be completed. Refresh and try again.'},500);
 }
}
Deno.serve(handler);
