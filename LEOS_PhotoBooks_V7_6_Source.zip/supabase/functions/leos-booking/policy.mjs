export function fail(message,status=400){throw Object.assign(Error(message),{status});}
export function id(x){if(!/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(x||''))fail('Invalid reference.');return x;}
const text=(x,min,max,label)=>{if(typeof x!=='string'||x.trim().length<min||x.trim().length>max)fail('Check '+label+'.');return x.trim();};
const n=(x,min,max,label)=>{const v=Number(x);if(x===''||!Number.isInteger(v)||v<min||v>max)fail('Check '+label+'.');return v;};
const flag=x=>x===true;
export function clean(action,p={}){
 if(action==='settings')return {display_name:text(p.display_name,2,90,'public business name'),enabled:flag(p.enabled),timezone:text(p.timezone,3,80,'time zone'),lead_minutes:n(p.lead_minutes,0,10080,'booking notice'),cancel_hours:n(p.cancel_hours,0,168,'cancellation cutoff'),horizon_days:n(p.horizon_days,1,90,'booking horizon'),instructions:text(p.instructions||'',0,1000,'instructions')};
 if(action==='service'){const duration=n(p.duration,15,480,'duration'),buffer=n(p.buffer,0,120,'buffer');if(duration%15||buffer%15)fail('Use 15-minute increments.');const price=Number(p.price);if(!Number.isFinite(price)||price<0||price>1000000)fail('Check price.');return {id:id(p.id),name:text(p.name,2,100,'service name'),duration,buffer,price:Math.round(price*100)/100,active:flag(p.active),onsite:flag(p.onsite)};}
 if(action==='resource'){
 const hours={};for(let d=0;d<7;d++){const windows=p.hours?.[d]||[];if(!Array.isArray(windows)||windows.length>3)fail('Use at most three work periods each day.');hours[d]=windows.map(w=>{if(!Array.isArray(w)||w.length!==2||!w.every(t=>typeof t==='string'&&/^([01]\d|2[0-3]):[0-5]\d$/.test(t))||w[0]>=w[1])fail('Check working hours. Overnight periods must be split across days.');if(w.some(t=>Number(t.slice(3))%15))fail('Use 15-minute increments.');return w;}).sort((a,b)=>a[0].localeCompare(b[0]));for(let i=1;i<hours[d].length;i++)if(hours[d][i][0]<hours[d][i-1][1])fail('Working periods overlap.');}
 return {id:id(p.id),name:text(p.name,2,80,'staff display name'),hours,active:flag(p.active)};
 }
 if(action==='block'){const a=Date.parse(p.starts_at),b=Date.parse(p.ends_at);if(!Number.isFinite(a)||!Number.isFinite(b)||b<=a||b-a>366*86400000)fail('Check time-off dates.');return {resource_id:id(p.resource_id),starts_at:new Date(a).toISOString(),ends_at:new Date(b).toISOString()};}
 if(action==='unblock')return {id:id(p.id)};
 if(action==='status'){if(!['completed','cancelled','no_show'].includes(p.status))fail('Choose a valid appointment status.');return {id:id(p.id),status:p.status};}
 fail('Unknown scheduling action.');
}
export function customer(p){return {name:text(p.name,2,100,'your name'),phone:text(p.phone,7,40,'phone'),address:text(p.address||'',0,400,'service address')};}
export function day(x){if(!/^\d{4}-\d{2}-\d{2}$/.test(x||'')||!Number.isFinite(Date.parse(x+'T12:00:00Z'))||new Date(x+'T12:00:00Z').toISOString().slice(0,10)!==x)fail('Choose a valid date.');return x;}
