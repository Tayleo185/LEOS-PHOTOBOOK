-- Disposable synthetic users and bookings; all test changes roll back.
begin;
insert into auth.users(id,email) values ('81111111-1111-4111-8111-111111111111','booking-test-owner@example.invalid'),('82222222-2222-4222-8222-222222222222','booking-test-customer@example.invalid'),('83333333-3333-4333-8333-333333333333','booking-test-stranger@example.invalid');
set local role service_role;
insert into public.leos_companies(id,name,created_by) values('8aaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','Booking Test Only','81111111-1111-4111-8111-111111111111');
select public.leos_manage_booking('8aaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','81111111-1111-4111-8111-111111111111','settings','{"display_name":"Booking Test Only","enabled":true,"timezone":"America/Chicago","lead_minutes":0,"cancel_hours":24,"horizon_days":60,"instructions":""}');
select public.leos_manage_booking('8aaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','81111111-1111-4111-8111-111111111111','service','{"id":"8bbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb","name":"Test service","duration":60,"buffer":15,"price":45,"onsite":true,"active":true}');
select public.leos_manage_booking('8aaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','81111111-1111-4111-8111-111111111111','resource','{"id":"8ccccccc-cccc-4ccc-8ccc-cccccccccccc","name":"Test staff","active":true,"hours":{"0":[["09:00","12:00"],["13:00","17:00"]],"1":[["09:00","12:00"],["13:00","17:00"]],"2":[["09:00","12:00"],["13:00","17:00"]],"3":[["09:00","12:00"],["13:00","17:00"]],"4":[["09:00","12:00"],["13:00","17:00"]],"5":[["09:00","12:00"],["13:00","17:00"]],"6":[["09:00","12:00"],["13:00","17:00"]]}}');
do $$
declare cid uuid='8aaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'; sid uuid='8bbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb'; rid uuid='8ccccccc-cccc-4ccc-8ccc-cccccccccccc'; cust uuid='82222222-2222-4222-8222-222222222222'; ap uuid='8ddddddd-dddd-4ddd-8ddd-dddddddddddd'; d date=(now() at time zone 'America/Chicago')::date+3; t timestamptz; repeated uuid; n integer;
begin
 t=(d+time '09:00') at time zone 'America/Chicago';
 select count(*) into n from public.leos_booking_slots(cid,sid,rid,d);
 if n=0 then raise exception 'FAIL: no working-hour slots'; end if;
 if exists(select 1 from public.leos_booking_slots(cid,sid,rid,d) where (starts_at at time zone 'America/Chicago')::time='12:00') then raise exception 'FAIL: lunch break bookable'; end if;
 perform public.leos_book_appointment(cid,sid,rid,t,cust,'Synthetic Customer','test@example.invalid','5551234567','123 Test Street',ap);
 repeated=public.leos_book_appointment(cid,sid,rid,t,cust,'Synthetic Customer','test@example.invalid','5551234567','123 Test Street',ap);
 if repeated<>ap or (select count(*) from public.leos_appointments where company_id=cid)<>1 then raise exception 'FAIL: retry duplicates appointment'; end if;
 if exists(select 1 from public.leos_booking_slots(cid,sid,rid,d) where starts_at<t+interval '75 minutes') then raise exception 'FAIL: service/buffer overlap allowed'; end if;
 if not exists(select 1 from public.leos_booking_slots(cid,sid,rid,d) where starts_at=t+interval '75 minutes') then raise exception 'FAIL: adjacent slot incorrectly blocked'; end if;
 begin
  perform public.leos_book_appointment(cid,sid,rid,t,cust,'Synthetic Customer','test@example.invalid','5551234567','123 Test Street',gen_random_uuid());
  raise exception 'FAIL: double booking accepted';
 exception when raise_exception then if sqlerrm like 'FAIL:%' then raise; end if; end;
 -- Even a service-level insert bypassing the scheduling RPC cannot overlap.
 begin
  insert into public.leos_appointments select gen_random_uuid(),company_id,resource_id,service_id,customer_id,customer_name,email,phone,address,starts_at,ends_at,occupied,status,service_name,resource_name,price,created_at,updated_at from public.leos_appointments where id=ap;
  raise exception 'FAIL: exclusion constraint bypassed';
 exception when exclusion_violation then null; end;
 begin
  perform public.leos_cancel_appointment(ap,'83333333-3333-4333-8333-333333333333');raise exception 'FAIL: stranger cancellation';
 exception when raise_exception then if sqlerrm like 'FAIL:%' then raise; end if; end;
 perform public.leos_book_appointment(cid,sid,rid,(d+time '13:00') at time zone 'America/Chicago',cust,'Synthetic Customer','test@example.invalid','5551234567','123 Test Street',ap,ap);
 if (select starts_at from public.leos_appointments where id=ap)<>((d+time '13:00') at time zone 'America/Chicago') then raise exception 'FAIL: reschedule failed'; end if;
 if not exists(select 1 from public.leos_booking_slots(cid,sid,rid,d) where starts_at=t) then raise exception 'FAIL: original slot not released'; end if;
 perform public.leos_cancel_appointment(ap,cust);
 if (select status from public.leos_appointments where id=ap)<>'cancelled' then raise exception 'FAIL: cancellation'; end if;
 if not exists(select 1 from public.leos_booking_slots(cid,sid,rid,d) where (starts_at at time zone 'America/Chicago')::time='13:00') then raise exception 'FAIL: cancelled slot not released'; end if;
 perform public.leos_manage_booking(cid,'81111111-1111-4111-8111-111111111111','block',jsonb_build_object('resource_id',rid,'starts_at',(d+time '15:00') at time zone 'America/Chicago','ends_at',(d+time '16:00') at time zone 'America/Chicago'));
 if exists(select 1 from public.leos_booking_slots(cid,sid,rid,d) where (starts_at at time zone 'America/Chicago')::time='15:00') then raise exception 'FAIL: time off ignored'; end if;
 begin
  perform public.leos_manage_booking(cid,cust,'status',jsonb_build_object('id',ap,'status','completed'));raise exception 'FAIL: customer admin access';
 exception when raise_exception then if sqlerrm like 'FAIL:%' then raise; end if; end;
 update public.leos_booking_settings set enabled=false where company_id=cid;
 if exists(select 1 from public.leos_booking_slots(cid,sid,rid,d)) then raise exception 'FAIL: disabled business exposes slots'; end if;
 if has_function_privilege('authenticated','public.leos_booking_slots(uuid,uuid,uuid,date,uuid)','execute') or has_function_privilege('anon','public.leos_cancel_appointment(uuid,uuid)','execute') then raise exception 'FAIL: protected RPC exposed'; end if;
 if has_table_privilege('authenticated','public.leos_appointments','select') or has_table_privilege('anon','public.leos_appointments','select') then raise exception 'FAIL: raw customer data exposed'; end if;
end $$;
rollback;
select 'PASS: slots, breaks, buffers, retry safety, exclusion, customer ownership, rescheduling, cancellation, time off, manager authorization and closed public data. All fixtures rolled back.' as result;
