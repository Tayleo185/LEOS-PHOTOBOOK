export const PLANS = {
 preview:{name:'Early access',trucks:25,members:10},
 solo:{name:'Solo',trucks:1,members:1},
 small_fleet:{name:'Small Fleet',trucks:5,members:10},
 fleet:{name:'Fleet',trucks:25,members:50}
};
export const ROLES=['owner','admin','dispatcher','driver','staff','bookkeeper'];
export const KINDS=['load','fuel','expense','fee','settlement','draw','taxPayment','truck','maintenance','inspection','reminder','income','invoice','bill','contribution','taxDeadline'];
export function fail(message,status=400){throw Object.assign(new Error(message),{status});}
export function isManager(role){return role==='owner'||role==='admin';}
export function canReadItem(role,userId,item){return !['driver','staff'].includes(role)||item.created_by===userId||item.assigned_to===userId;}
export function canWriteKind(role,kind){
 if(isManager(role))return true;
 if(role==='dispatcher')return ['load','truck','maintenance','inspection','reminder'].includes(kind);
 if(role==='bookkeeper')return ['load','fuel','expense','fee','settlement','draw','taxPayment','income','invoice','bill','contribution','taxDeadline'].includes(kind);
 return ['driver','staff'].includes(role)&&['fuel','expense','inspection','reminder'].includes(kind);
}
export function writable(company){
 if(company.suspended)fail('This company is suspended. Existing data remains stored.',403);
 if(!['preview','active','trialing'].includes(company.subscription_status))fail('This company is read-only. The owner can update billing; records and exports remain available.',402);
}
export function uuid(value){if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value||'')))fail('Invalid identifier.');return value;}
export function cleanPayload(input){
 if(!input||typeof input!=='object'||Array.isArray(input))fail('Record details are required.');
 if(JSON.stringify(input).length>40000)fail('Record is too large. Upload attachments separately.');
 const out={};
 for(const key of ['description','date','status','loadNo','origin','destination','pickupDate','deliveryDate','notes','category','vehicle','unit','vin','make','model','year','dueDate','vendor','paidBy','paymentRef','settlementId','payMode','customer','reference','taxType','jurisdiction','taxPeriod','taxYear','taxReview']){
  if(input[key]!==undefined){if(typeof input[key]!=='string')fail('Invalid '+key);out[key]=input[key].trim().slice(0,key==='notes'?8000:500);}
 }
 if(!out.description)fail('Enter a description.');
 for(const key of ['amount','miles','gallons','unitPrice','credit','loadShare','driverPay','odometer','payPerMile']){
  if(input[key]!==undefined&&input[key]!==''){
   const n=Number(input[key]);if(!Number.isFinite(n)||n<0||n>1e9)fail('Enter a valid '+key+'.');const precision=['gallons','unitPrice'].includes(key)?1000:100;out[key]=Math.round(n*precision)/precision;
  }
 }
 if(out.loadShare!==undefined&&out.loadShare>100)fail('Load share must be between 0 and 100.');
 if(out.payMode&&!['percent','cpm','gross'].includes(out.payMode))fail('Invalid pay calculation.');
 if(out.paidBy&&!['self','company','carrier','other'].includes(out.paidBy))fail('Invalid expense payer.');
 if(out.taxYear&&!/^(19|20|21)\d{2}$/.test(out.taxYear))fail('Enter a valid tax year.');
 if(out.taxReview&&!['needs_review','reviewed','not_deductible'].includes(out.taxReview))fail('Choose a valid tax review status.');
 if(out.taxType&&!['income_estimate','income_return','sales','payroll','property','other'].includes(out.taxType))fail('Choose a valid tax type.');
 for(const k of ['date','pickupDate','deliveryDate','dueDate'])if(out[k]){
  const date=new Date(out[k]+'T12:00:00Z');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(out[k])||!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==out[k])fail('Use a valid date.');
 }
 if(out.status&&!['scheduled','in_transit','completed','paid','open','done','active','out_of_service'].includes(out.status))fail('Invalid record status.');
 return out;
}
export function validateAssignment(role,userId,assigned){if(['driver','staff'].includes(role)&&assigned&&assigned!==userId)fail('Drivers and staff can only assign their own records.',403);}
export function verifyFileSignature(bytes,mime){
 const first=(...ns)=>ns.every((n,i)=>bytes[i]===n);
 if(mime==='application/pdf')return first(37,80,68,70,45);
 if(mime==='image/jpeg')return first(255,216,255);
 if(mime==='image/png')return first(137,80,78,71,13,10,26,10);
 if(mime==='image/webp')return first(82,73,70,70)&&bytes[8]===87&&bytes[9]===69&&bytes[10]===66&&bytes[11]===80;
 return false;
}
