export async function uploadIdentity({companyId,userId,itemId,bytes,mime}){
 const hex=buffer=>Array.from(new Uint8Array(buffer),v=>v.toString(16).padStart(2,'0')).join('');
 const hash=hex(await crypto.subtle.digest('SHA-256',bytes));
 const key=hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode([companyId,userId,itemId||'company',hash].join('|')))).slice(0,32);
 const id=key.slice(0,8)+'-'+key.slice(8,12)+'-8'+key.slice(13,16)+'-b'+key.slice(17,20)+'-'+key.slice(20,32);
 const ext={'image/jpeg':'jpg','image/png':'png','image/webp':'webp','application/pdf':'pdf'}[mime];if(!ext)throw Error('Invalid file format');
 return {id,path:[companyId,userId,itemId||'company',hash+'.'+ext].join('/')};
}
