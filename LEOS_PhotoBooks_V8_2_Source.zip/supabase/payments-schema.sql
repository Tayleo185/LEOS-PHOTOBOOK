-- Service-only full-payment confirmation. No existing records are rewritten.
create or replace function public.leos_confirm_payment(cid uuid,item uuid,actor uuid,payment_date date,expected_version integer,method text,reference text)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare original public.leos_company_items; company public.leos_companies; receipt uuid; amount numeric; existing uuid;
begin
 if not exists(select 1 from public.leos_company_members where company_id=cid and user_id=actor and role in ('owner','admin','bookkeeper')) then raise exception 'Financial access required'; end if;
 select * into company from public.leos_companies where id=cid for update;
 if company.id is null or company.suspended or company.subscription_status not in ('preview','active','trialing') then raise exception 'Company is read-only'; end if;
 if payment_date is null or not isfinite(payment_date) or payment_date<'1900-01-01'::date or payment_date>current_date+1 then raise exception 'Choose the actual payment date'; end if;
 if expected_version is null or expected_version<1 then raise exception 'Refresh the record before confirming payment'; end if;
 if method is null or method not in ('cash','card','bank_transfer','check','other') or length(coalesce(reference,''))>120 then raise exception 'Choose a payment method and valid reference'; end if;
 select * into original from public.leos_company_items where id=item and company_id=cid and archived_at is null for update;
 if original.id is null or original.kind not in ('invoice','bill','load') then raise exception 'Invoice, bill or load not found'; end if;
 if original.kind in ('invoice','bill') then
  select id into existing from public.leos_company_items where company_id=cid and kind=case original.kind when 'invoice' then 'income' else 'expense' end and payload->>(case original.kind when 'invoice' then 'invoiceId' else 'billId' end)=item::text;
  if existing is not null then return jsonb_build_object('id',existing,'sourceId',item,'alreadyRecorded',true); end if;
  receipt:=public.leos_record_business_payment(cid,item,actor,payment_date,expected_version);
  update public.leos_company_items set payload=payload||jsonb_build_object('paymentMethod',method,'paymentRef',trim(coalesce(reference,'')),'paymentDate',payment_date::text,'paymentConfirmedAt',now()::text) where id in (item,receipt) and company_id=cid;
  return jsonb_build_object('id',receipt,'sourceId',item,'alreadyRecorded',false);
 end if;
 if original.payload->>'status'='paid' then return jsonb_build_object('id',item,'sourceId',item,'alreadyRecorded',true); end if;
 if original.payload->>'status' is distinct from 'completed' then raise exception 'Complete delivery before confirming load payment'; end if;
 if original.version is distinct from expected_version then raise exception 'This record changed. Refresh before confirming payment'; end if;
 amount:=case when original.payload->>'payMode'='cpm' then coalesce((original.payload->>'miles')::numeric,0)*coalesce((original.payload->>'payPerMile')::numeric,0) when original.payload->>'payMode'='gross' then coalesce((original.payload->>'amount')::numeric,0) else coalesce((original.payload->>'amount')::numeric,0)*coalesce((original.payload->>'loadShare')::numeric,(company.settings->>'loadShare')::numeric,100)/100 end;
 if amount<=0 then raise exception 'Enter confirmed load pay before confirming payment'; end if;
 update public.leos_company_items set payload=payload||jsonb_build_object('status','paid','paymentDate',payment_date::text,'paymentMethod',method,'paymentRef',trim(coalesce(reference,'')),'paymentConfirmedAt',now()::text),version=version+1,updated_at=now() where id=item and company_id=cid;
 insert into public.leos_company_audit(company_id,actor_id,action,detail) values(cid,actor,'payment.confirmed',jsonb_build_object('sourceId',item,'kind','load','amount',round(amount,2),'paymentDate',payment_date));
 return jsonb_build_object('id',item,'sourceId',item,'alreadyRecorded',false);
end $$;
revoke all on function public.leos_confirm_payment(uuid,uuid,uuid,date,integer,text,text) from public,anon,authenticated;
grant execute on function public.leos_confirm_payment(uuid,uuid,uuid,date,integer,text,text) to service_role;

create unique index if not exists leos_one_appointment_invoice on public.leos_company_items(company_id,(payload->>'appointmentId')) where kind='invoice' and payload ? 'appointmentId';
create or replace function public.leos_invoice_appointment(cid uuid,appointment uuid,actor uuid)
returns uuid language plpgsql security invoker set search_path='' as $$
declare company public.leos_companies; booking public.leos_appointments; invoice uuid; day date; tz text;
begin
 if not exists(select 1 from public.leos_company_members where company_id=cid and user_id=actor and role in ('owner','admin','bookkeeper')) then raise exception 'Financial access required'; end if;
 select * into company from public.leos_companies where id=cid for update;
 if company.id is null or company.suspended or company.subscription_status not in ('preview','active','trialing') then raise exception 'Company is read-only'; end if;
 select * into booking from public.leos_appointments where company_id=cid and id=appointment for update;
 if booking.id is null then raise exception 'Appointment not found'; end if;
 select id into invoice from public.leos_company_items where company_id=cid and kind='invoice' and payload->>'appointmentId'=appointment::text;
 if invoice is not null then return invoice; end if;
 if booking.status<>'completed' then raise exception 'Complete the appointment before preparing an invoice'; end if;
 if booking.price<=0 then raise exception 'Use a manual invoice for a free or unpriced appointment'; end if;
 select timezone into tz from public.leos_booking_settings where company_id=cid;
 day:=(booking.starts_at at time zone coalesce(tz,'UTC'))::date;
 invoice:=gen_random_uuid();
 insert into public.leos_company_items(id,company_id,kind,created_by,payload) values(invoice,cid,'invoice',actor,jsonb_build_object('description',booking.service_name||' — '||booking.customer_name,'customer',booking.customer_name,'date',day::text,'status','open','amount',booking.price,'appointmentId',appointment::text,'reference','APPT-'||right(appointment::text,8),'notes','Created from the listed appointment price. Review final charges and any applicable taxes before confirming payment.'));
 insert into public.leos_company_audit(company_id,actor_id,action,detail) values(cid,actor,'appointment.invoiced',jsonb_build_object('appointmentId',appointment,'invoiceId',invoice));
 return invoice;
end $$;
revoke all on function public.leos_invoice_appointment(uuid,uuid,uuid) from public,anon,authenticated;
grant execute on function public.leos_invoice_appointment(uuid,uuid,uuid) to service_role;
