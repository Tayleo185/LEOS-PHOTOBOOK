-- Additive installment receipts. Existing invoiceId/billId unique indexes stay intact.
create or replace function public.leos_record_installment(cid uuid,item uuid,actor uuid,payment_date date,expected_version integer,method text,reference text,payment_amount numeric,payment_id uuid,payment_type text)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare original public.leos_company_items; company public.leos_companies; total numeric; paid numeric; remainder numeric; event jsonb; existing jsonb; source uuid;
begin
 if not exists(select 1 from public.leos_company_members where company_id=cid and user_id=actor and role in ('owner','admin','bookkeeper')) then raise exception 'Financial access required';end if;
 select * into company from public.leos_companies where id=cid for update;
 if company.id is null or company.suspended or company.subscription_status not in ('preview','active','trialing') then raise exception 'Company is read-only';end if;
 if payment_date is null or not isfinite(payment_date) or payment_date<'1900-01-01'::date or payment_date>current_date+1 then raise exception 'Choose actual payment date';end if;
 if payment_id is null or expected_version is null or expected_version<1 then raise exception 'Reopen payment confirmation';end if;
 if method is null or method not in ('cash','card','bank_transfer','check','other') or length(coalesce(reference,''))>120 then raise exception 'Choose payment method and valid reference';end if;
 if payment_amount is null or payment_amount::text in ('NaN','Infinity','-Infinity') or payment_amount<=0 or payment_amount>100000000 or payment_amount<>round(payment_amount,2) then raise exception 'Enter a positive payment with no more than two decimal places';end if;
 if payment_type is null or payment_type not in ('payment','deposit') then raise exception 'Choose payment type';end if;
 select i.id,p into source,existing from public.leos_company_items i cross join lateral jsonb_array_elements(coalesce(i.payload->'payments','[]'::jsonb)) p where i.company_id=cid and p->>'id'=payment_id::text limit 1;
 if source is not null then
  if source<>item or (existing->>'amount')::numeric<>payment_amount or existing->>'date'<>payment_date::text or existing->>'method'<>method or existing->>'type'<>payment_type or existing->>'reference'<>trim(coalesce(reference,'')) then raise exception 'Payment identifier reused with different details';end if;
  return jsonb_build_object('id',payment_id,'sourceId',item,'alreadyRecorded',true);
 end if;
 select * into original from public.leos_company_items where id=item and company_id=cid and archived_at is null for update;
 if original.id is null or original.kind not in ('invoice','bill','load') then raise exception 'Invoice, bill or load not found';end if;
 if original.version<>expected_version then raise exception 'Record changed. Refresh before recording payment';end if;
 if original.payload->>'status'='paid' then raise exception 'Already paid';end if;
 if original.kind='load' and original.payload->>'status' is distinct from 'completed' then raise exception 'Complete delivery before recording load payments';end if;
 if payment_type='deposit' and original.kind<>'invoice' then raise exception 'Deposits must be linked to an invoice';end if;
 total:=round(case when original.kind='load' and original.payload ? 'paymentTotal' then (original.payload->>'paymentTotal')::numeric when original.kind<>'load' then coalesce((original.payload->>'amount')::numeric,0) when original.payload->>'payMode'='cpm' then coalesce((original.payload->>'miles')::numeric,0)*coalesce((original.payload->>'payPerMile')::numeric,0) when original.payload->>'payMode'='gross' then coalesce((original.payload->>'amount')::numeric,0) else coalesce((original.payload->>'amount')::numeric,0)*coalesce((original.payload->>'loadShare')::numeric,(company.settings->>'loadShare')::numeric,100)/100 end,2);
 paid:=coalesce((original.payload->>'paidAmount')::numeric,0);
 if total<=0 or payment_amount>total-paid then raise exception 'Payment exceeds remaining balance';end if;
 remainder:=total-paid-payment_amount;
 event:=jsonb_build_object('id',payment_id,'amount',payment_amount,'date',payment_date::text,'method',method,'reference',trim(coalesce(reference,'')),'type',payment_type,'confirmedAt',now()::text);
 if original.kind in ('invoice','bill') then
  insert into public.leos_company_items(id,company_id,kind,created_by,payload) values(payment_id,cid,case original.kind when 'invoice' then 'income' else 'expense' end,actor,jsonb_build_object(case original.kind when 'invoice' then 'sourceInvoiceId' else 'sourceBillId' end,item::text,'description',case original.kind when 'invoice' then 'Payment received: ' else 'Bill paid: ' end||(original.payload->>'description'),'amount',payment_amount,'date',payment_date::text,'status','paid','paidBy','company','paymentDate',payment_date::text,'paymentMethod',method,'paymentRef',trim(coalesce(reference,'')),'paymentType',payment_type,'paymentConfirmedAt',now()::text));
 end if;
 update public.leos_company_items set payload=payload||jsonb_build_object('paymentTotal',total,'paidAmount',paid+payment_amount,'payments',coalesce(payload->'payments','[]'::jsonb)||jsonb_build_array(event),'status',case when remainder=0 then 'paid' when original.kind='load' then 'completed' else 'partial' end,'paymentDate',payment_date::text,'paymentMethod',method,'paymentRef',trim(coalesce(reference,'')),'paymentConfirmedAt',now()::text),version=version+1,updated_at=now() where id=item and company_id=cid;
 insert into public.leos_company_audit(company_id,actor_id,action,detail) values(cid,actor,'payment.installment',jsonb_build_object('sourceId',item,'paymentId',payment_id,'amount',payment_amount,'remaining',remainder,'type',payment_type));
 return jsonb_build_object('id',payment_id,'sourceId',item,'alreadyRecorded',false,'remaining',remainder);
end $$;
revoke all on function public.leos_record_installment(uuid,uuid,uuid,date,integer,text,text,numeric,uuid,text) from public,anon,authenticated;
grant execute on function public.leos_record_installment(uuid,uuid,uuid,date,integer,text,text,numeric,uuid,text) to service_role;

-- Old clients must not overwrite installment balances.
create or replace function public.leos_record_business_payment(cid uuid,item uuid,actor uuid,payment_date date,expected_version integer)
returns uuid language plpgsql security invoker set search_path='' as $$
declare original public.leos_company_items; receipt_id uuid; receipt_kind text; link_key text;
begin
 select * into original from public.leos_company_items where company_id=cid and id=item and archived_at is null for update;
 if original.id is null or original.kind not in ('invoice','bill') then raise exception 'Invoice or bill not found.'; end if;
 if coalesce((original.payload->>'paidAmount')::numeric,0)>0 then raise exception 'Use the latest Payments page for remaining balances';end if;
 receipt_kind:=case original.kind when 'invoice' then 'income' else 'expense' end;
 link_key:=case original.kind when 'invoice' then 'invoiceId' else 'billId' end;
 select id into receipt_id from public.leos_company_items where company_id=cid and kind=receipt_kind and payload->>link_key=item::text;
 if receipt_id is not null then return receipt_id; end if;
 if original.version<>expected_version then raise exception 'This record changed. Refresh before recording payment.'; end if;
 if original.payload->>'status'='paid' then raise exception 'This record is already marked paid.'; end if;
 if coalesce((original.payload->>'amount')::numeric,0)<=0 then raise exception 'Enter a positive amount before recording payment.'; end if;
 receipt_id:=gen_random_uuid();
 insert into public.leos_company_items(id,company_id,kind,created_by,payload)
 values(receipt_id,cid,receipt_kind,actor,original.payload||jsonb_build_object(link_key,item::text,'date',payment_date::text,'status','paid','description',case original.kind when 'invoice' then 'Payment received: ' else 'Bill paid: ' end||(original.payload->>'description'),'paidBy','company'));
 update public.leos_company_items set payload=payload||'{"status":"paid"}'::jsonb,version=version+1,updated_at=now() where id=item;
 insert into public.leos_company_audit(company_id,actor_id,action,detail) values(cid,actor,'payment.recorded',jsonb_build_object('sourceId',item,'receiptId',receipt_id,'kind',original.kind));
 return receipt_id;
end $$;

-- Service-only full-payment confirmation. No existing records are rewritten.
create or replace function public.leos_confirm_payment(cid uuid,item uuid,actor uuid,payment_date date,expected_version integer,method text,reference text)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare original public.leos_company_items; company public.leos_companies; receipt uuid; amount numeric; existing uuid;
begin
 if not exists(select 1 from public.leos_company_members where company_id=cid and user_id=actor and role in ('owner','admin','bookkeeper')) then raise exception 'Financial access required'; end if;
 select * into company from public.leos_companies where id=cid for update;
 if company.id is null or company.suspended or company.subscription_status not in ('preview','active','trialing') then raise exception 'Company is read-only'; end if;
 if payment_date is null or not isfinite(payment_date) or payment_date<'1900-01-01'::date or payment_date>current_date+1 then raise exception 'Choose the actual payment date'; end if;
 if expected_version is null or expected_version<1 then raise exception 'Refresh the record before confirming payment'; end if;
 if method is null or method not in ('cash','card','bank_transfer','check','other') or length(coalesce(reference,''))>120 then raise exception 'Choose a payment method and valid reference'; end if;
 select * into original from public.leos_company_items where id=item and company_id=cid and archived_at is null for update;
 if original.id is null or original.kind not in ('invoice','bill','load') then raise exception 'Invoice, bill or load not found'; end if;
 if coalesce((original.payload->>'paidAmount')::numeric,0)>0 then raise exception 'Use the latest Payments page for remaining balances';end if;
 if original.kind in ('invoice','bill') then
  select id into existing from public.leos_company_items where company_id=cid and kind=case original.kind when 'invoice' then 'income' else 'expense' end and payload->>(case original.kind when 'invoice' then 'invoiceId' else 'billId' end)=item::text;
  if existing is not null then return jsonb_build_object('id',existing,'sourceId',item,'alreadyRecorded',true); end if;
  receipt:=public.leos_record_business_payment(cid,item,actor,payment_date,expected_version);
  update public.leos_company_items set payload=payload||jsonb_build_object('paymentMethod',method,'paymentRef',trim(coalesce(reference,'')),'paymentDate',payment_date::text,'paymentConfirmedAt',now()::text) where id in (item,receipt) and company_id=cid;
  return jsonb_build_object('id',receipt,'sourceId',item,'alreadyRecorded',false);
 end if;
 if original.payload->>'status'='paid' then return jsonb_build_object('id',item,'sourceId',item,'alreadyRecorded',true); end if;
 if original.payload->>'status' is distinct from 'completed' then raise exception 'Complete delivery before confirming load payment'; end if;
 if original.version is distinct from expected_version then raise exception 'This record changed. Refresh before confirming payment'; end if;
 amount:=case when original.payload->>'payMode'='cpm' then coalesce((original.payload->>'miles')::numeric,0)*coalesce((original.payload->>'payPerMile')::numeric,0) when original.payload->>'payMode'='gross' then coalesce((original.payload->>'amount')::numeric,0) else coalesce((original.payload->>'amount')::numeric,0)*coalesce((original.payload->>'loadShare')::numeric,(company.settings->>'loadShare')::numeric,100)/100 end;
 if amount<=0 then raise exception 'Enter confirmed load pay before confirming payment'; end if;
 update public.leos_company_items set payload=payload||jsonb_build_object('status','paid','paymentDate',payment_date::text,'paymentMethod',method,'paymentRef',trim(coalesce(reference,'')),'paymentConfirmedAt',now()::text),version=version+1,updated_at=now() where id=item and company_id=cid;
 insert into public.leos_company_audit(company_id,actor_id,action,detail) values(cid,actor,'payment.confirmed',jsonb_build_object('sourceId',item,'kind','load','amount',round(amount,2),'paymentDate',payment_date));
 return jsonb_build_object('id',item,'sourceId',item,'alreadyRecorded',false);
end $$;
revoke all on function public.leos_confirm_payment(uuid,uuid,uuid,date,integer,text,text) from public,anon,authenticated;
grant execute on function public.leos_confirm_payment(uuid,uuid,uuid,date,integer,text,text) to service_role;

