# Leo 8.1 receipt-reader fix — prepared, not deployed

Fixes retail receipts being treated as invoices because they contain an Invoice Number label, purchase dates printed as MM/DD/YYYY, and missing draft creation for new receipts.

Long images are enlarged and the sale area is OCR-read twice with different layouts. Totals are read from explicit Total/Grand Total labels; subtotal, rewards and barcode sections are excluded. Merchant, purchase date, fuel gallons, unit price, transaction reference and scale-ticket category populate a review draft. Disagreeing totals/dates and future OCR dates are left unresolved. Logo spelling recoveries are explicitly marked for review. No amount is inferred from a missing total.

Overview/Documents > Read and match a document > choose a photo > Review fuel/expense draft. Check amount, date, merchant and Paid by, then Save. The original image attaches to the saved record. Existing record matches and exact-image checks help avoid duplicates. This does not mark invoices or loads paid. OCR is not document/payment authentication.

Validation: 68 Node tests passed. Local Tesseract extraction of the two supplied private receipts recovered both purchase totals and the diesel quantities. Their private photos and OCR text are excluded from this package. Browser testing and deployment could not complete: the browser control service timed out and GitHub connector methods returned Unknown tool. The production site remains 8.0. No database changes were made.

## Deployment patch
Keep all existing repository files. Upload the patch files to the repository root on main: index.html, company.html, app81.mjs, document-match81.mjs, photo-completion81.mjs, receipt-reader81.mjs and this note. The unchanged domain80/payments80/insights80, scheduling79, style80, photo-policy78 and trip assets must remain. Deploy the resulting main commit to the existing Render static site. No Supabase migration or database deletion is needed.

The included source archive contains the structured implementation and tests. Once browser access returns, verify both receipt review drafts, missing/disputed-date required fields and original-photo attachment before treating the release as fully browser-verified.
