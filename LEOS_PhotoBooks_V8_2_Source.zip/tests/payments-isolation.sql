-- Synthetic records only. Roll back every record, account and audit entry.
begin;
insert into auth.users(id,email) values ('11111111-1111-4111-8111-111111111111','payments-owner@example.invalid'),('22222222-2222-4222-8222-222222222222','payments-driver@example.invalid'),('33333333-3333-4333-8333-333333333333','payments-other@example.invalid');
set local role service_role;
do $$
declare cid uuid:=gen_random_uuid(); other_cid uuid:=gen_random_uuid(); inv uuid:=gen_random_uuid(); bill uuid:=gen_random_uuid(); load uuid:=gen_random_uuid(); foreign_item uuid:=gen_random_uuid(); stale uuid:=gen_random_uuid(); service uuid:=gen_random_uuid(); resource uuid:=gen_random_uuid(); appointment uuid:=gen_random_uuid(); result jsonb; again jsonb; appointment_invoice uuid;
begin
 insert into public.leos_companies(id,name,created_by,settings) values(cid,'Synthetic Payments A','11111111-1111-4111-8111-111111111111','{"loadShare":88}'),(other_cid,'Synthetic Payments B','33333333-3333-4333-8333-333333333333','{}');
 insert into public.leos_company_members(company_id,user_id,role,email) values(cid,'22222222-2222-4222-8222-222222222222','driver','payments-driver@example.invalid');
 insert into public.leos_company_items(id,company_id,kind,created_by,payload) values
 (inv,cid,'invoice','11111111-1111-4111-8111-111111111111','{"description":"Synthetic invoice","amount":500,"date":"2026-10-03","status":"open"}'),
 (bill,cid,'bill','11111111-1111-4111-8111-111111111111','{"description":"Synthetic bill","amount":100,"status":"open"}'),
 (load,cid,'load','11111111-1111-4111-8111-111111111111','{"description":"Synthetic load","amount":1000,"loadShare":88,"date":"2026-10-03","status":"completed"}'),
 (stale,cid,'load','11111111-1111-4111-8111-111111111111','{"description":"Stale load","amount":500,"status":"completed"}'),
 (foreign_item,other_cid,'invoice','33333333-3333-4333-8333-333333333333','{"description":"Private other company","amount":600,"status":"open"}');
 result:=public.leos_confirm_payment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,1,'cash','TEST');
 again:=public.leos_confirm_payment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,1,'cash','TEST');
 if result->>'id'<>again->>'id' or again->>'alreadyRecorded'<>'true' then raise exception 'FAIL: invoice retry'; end if;
 if (select count(*) from public.leos_company_items where company_id=cid and kind='income')<>1 then raise exception 'FAIL: duplicate income'; end if;
 if (select payload->>'paymentMethod' from public.leos_company_items where id=(result->>'id')::uuid)<>'cash' then raise exception 'FAIL: missing payment method'; end if;
 perform public.leos_confirm_payment(cid,bill,'11111111-1111-4111-8111-111111111111',current_date,1,'bank_transfer','BILL');
 result:=public.leos_confirm_payment(cid,load,'11111111-1111-4111-8111-111111111111',current_date,1,'check','LOAD');
 again:=public.leos_confirm_payment(cid,load,'11111111-1111-4111-8111-111111111111',current_date,1,'check','LOAD');
 if again->>'alreadyRecorded'<>'true' or (select payload->>'status' from public.leos_company_items where id=load)<>'paid' then raise exception 'FAIL: load payment'; end if;
 if (select count(*) from public.leos_company_items where company_id=cid and kind='income')<>1 then raise exception 'FAIL: load counted twice as income'; end if;
 if (select payload->>'date' from public.leos_company_items where id=load)<>'2026-10-03' then raise exception 'FAIL: original earned date changed'; end if;
 if (select payload->>'paymentDate' from public.leos_company_items where id=load)<>current_date::text then raise exception 'FAIL: actual payment date missing'; end if;
 begin perform public.leos_confirm_payment(cid,foreign_item,'11111111-1111-4111-8111-111111111111',current_date,1,'cash','');raise exception 'FAIL: cross-company accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 begin perform public.leos_confirm_payment(cid,stale,'22222222-2222-4222-8222-222222222222',current_date,1,'cash','');raise exception 'FAIL: driver accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 begin perform public.leos_confirm_payment(cid,stale,'11111111-1111-4111-8111-111111111111',current_date,99,'cash','');raise exception 'FAIL: stale version accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 begin perform public.leos_confirm_payment(cid,stale,'11111111-1111-4111-8111-111111111111',current_date,1,'fake','');raise exception 'FAIL: invalid method accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 insert into public.leos_booking_settings(company_id,slug,display_name) values(cid,'synthetic-'||replace(cid::text,'-',''),'Synthetic Payments A');
 insert into public.leos_booking_services(id,company_id,name,duration,price) values(service,cid,'Synthetic service',60,99);
 insert into public.leos_booking_resources(id,company_id,name) values(resource,cid,'Synthetic staff');
 insert into public.leos_appointments(id,company_id,resource_id,service_id,customer_id,customer_name,email,phone,starts_at,ends_at,occupied,status,service_name,resource_name,price) values(appointment,cid,resource,service,'22222222-2222-4222-8222-222222222222','Synthetic Customer','customer@example.invalid','5550000000',now()-interval '3 hours',now()-interval '2 hours',tstzrange(now()-interval '3 hours',now()-interval '2 hours','[)'),'completed','Synthetic service','Synthetic staff',99);
 appointment_invoice:=public.leos_invoice_appointment(cid,appointment,'11111111-1111-4111-8111-111111111111');
 if public.leos_invoice_appointment(cid,appointment,'11111111-1111-4111-8111-111111111111')<>appointment_invoice then raise exception 'FAIL: duplicate appointment invoice';end if;
 perform public.leos_confirm_payment(cid,appointment_invoice,'11111111-1111-4111-8111-111111111111',current_date,1,'card','APPT');
 if (select count(*) from public.leos_company_items where company_id=cid and kind='income')<>2 then raise exception 'FAIL: appointment income';end if;
 update public.leos_companies set suspended=true where id=cid;
 begin perform public.leos_confirm_payment(cid,stale,'11111111-1111-4111-8111-111111111111',current_date,1,'cash','');raise exception 'FAIL: suspended company accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 if has_function_privilege('anon','public.leos_confirm_payment(uuid,uuid,uuid,date,integer,text,text)','execute') or has_function_privilege('authenticated','public.leos_invoice_appointment(uuid,uuid,uuid)','execute') then raise exception 'FAIL: raw client can call payment functions';end if;
end $$;
rollback;
