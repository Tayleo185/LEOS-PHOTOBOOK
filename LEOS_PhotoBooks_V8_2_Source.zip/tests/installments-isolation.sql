begin;
insert into auth.users(id,email) values ('11111111-1111-4111-8111-111111111111','installment-owner@example.invalid'),('22222222-2222-4222-8222-222222222222','installment-driver@example.invalid'),('33333333-3333-4333-8333-333333333333','installment-other@example.invalid');
set local role service_role;
do $$
declare cid uuid:=gen_random_uuid();other_cid uuid:=gen_random_uuid();inv uuid:=gen_random_uuid();bill uuid:=gen_random_uuid();load uuid:=gen_random_uuid();foreign_item uuid:=gen_random_uuid();pid uuid:=gen_random_uuid();r jsonb;v integer;
begin
 insert into public.leos_companies(id,name,created_by,settings) values(cid,'Synthetic Installments','11111111-1111-4111-8111-111111111111','{"loadShare":88}'),(other_cid,'Synthetic Other','33333333-3333-4333-8333-333333333333','{}');
 insert into public.leos_company_members(company_id,user_id,role,email) values(cid,'22222222-2222-4222-8222-222222222222','driver','installment-driver@example.invalid');
 insert into public.leos_company_items(id,company_id,kind,created_by,payload) values
 (inv,cid,'invoice','11111111-1111-4111-8111-111111111111','{"description":"Synthetic invoice","amount":500,"status":"open"}'),
 (bill,cid,'bill','11111111-1111-4111-8111-111111111111','{"description":"Synthetic bill","amount":100,"status":"open"}'),
 (load,cid,'load','11111111-1111-4111-8111-111111111111','{"description":"Synthetic load","amount":1000,"date":"2026-10-03","status":"completed"}'),
 (foreign_item,other_cid,'invoice','33333333-3333-4333-8333-333333333333','{"description":"Other invoice","amount":500,"status":"open"}');
 r:=public.leos_record_installment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,1,'cash','DEP',100,pid,'deposit');
 if (r->>'remaining')::numeric<>400 then raise exception 'FAIL: deposit balance';end if;
 r:=public.leos_record_installment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,1,'cash','DEP',100,pid,'deposit');
 if r->>'alreadyRecorded'<>'true' then raise exception 'FAIL: retry duplicates';end if;
 if (select count(*) from public.leos_company_items where company_id=cid and kind='income')<>1 then raise exception 'FAIL: duplicate receipt';end if;
 begin perform public.leos_record_installment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,2,'cash','DEP',101,pid,'deposit');raise exception 'FAIL: altered retry accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 begin perform public.leos_record_installment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,1,'cash','',10,gen_random_uuid(),'payment');raise exception 'FAIL: stale version accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 begin perform public.leos_record_installment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,2,'cash','',401,gen_random_uuid(),'payment');raise exception 'FAIL: overpayment accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 begin perform public.leos_confirm_payment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,2,'cash','');raise exception 'FAIL: old full confirmation bypass';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 begin perform public.leos_record_business_payment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,2);raise exception 'FAIL: old payment bypass';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 perform public.leos_record_installment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,2,'check','FINAL',400,gen_random_uuid(),'payment');
 if (select payload->>'status' from public.leos_company_items where id=inv)<>'paid' or (select sum((payload->>'amount')::numeric) from public.leos_company_items where company_id=cid and kind='income')<>500 then raise exception 'FAIL: final invoice totals';end if;
 perform public.leos_record_installment(cid,bill,'11111111-1111-4111-8111-111111111111',current_date,1,'bank_transfer','',40,gen_random_uuid(),'payment');
 perform public.leos_record_installment(cid,bill,'11111111-1111-4111-8111-111111111111',current_date,2,'bank_transfer','',60,gen_random_uuid(),'payment');
 if (select sum((payload->>'amount')::numeric) from public.leos_company_items where company_id=cid and kind='expense')<>100 then raise exception 'FAIL: bill totals';end if;
 perform public.leos_record_installment(cid,load,'11111111-1111-4111-8111-111111111111',current_date,1,'check','',300,gen_random_uuid(),'payment');
 update public.leos_companies set settings='{"loadShare":50}' where id=cid;
 perform public.leos_record_installment(cid,load,'11111111-1111-4111-8111-111111111111',current_date,2,'check','',580,gen_random_uuid(),'payment');
 if (select payload->>'paidAmount' from public.leos_company_items where id=load)::numeric<>880 or (select payload->>'date' from public.leos_company_items where id=load)<>'2026-10-03' then raise exception 'FAIL: load share/date changed';end if;
 if (select count(*) from public.leos_company_items where company_id=cid and kind='income')<>2 then raise exception 'FAIL: load creates duplicate revenue';end if;
 begin perform public.leos_record_installment(cid,foreign_item,'11111111-1111-4111-8111-111111111111',current_date,1,'cash','',10,gen_random_uuid(),'payment');raise exception 'FAIL: cross-company accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 begin perform public.leos_record_installment(cid,inv,'22222222-2222-4222-8222-222222222222',current_date,1,'cash','',10,gen_random_uuid(),'payment');raise exception 'FAIL: driver accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 begin perform public.leos_record_installment(cid,bill,'11111111-1111-4111-8111-111111111111',current_date,1,'cash','',1.001,gen_random_uuid(),'payment');raise exception 'FAIL: fractional cents accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 update public.leos_companies set suspended=true where id=cid;
 begin perform public.leos_record_installment(cid,inv,'11111111-1111-4111-8111-111111111111',current_date,1,'cash','',10,gen_random_uuid(),'payment');raise exception 'FAIL: suspended accepted';exception when others then if sqlerrm like 'FAIL:%' then raise;end if;end;
 if has_function_privilege('authenticated','public.leos_record_installment(uuid,uuid,uuid,date,integer,text,text,numeric,uuid,text)','execute') or has_function_privilege('anon','public.leos_record_installment(uuid,uuid,uuid,date,integer,text,text,numeric,uuid,text)','execute') then raise exception 'FAIL: client RPC privilege';end if;
end $$;
rollback;
