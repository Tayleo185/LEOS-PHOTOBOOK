import test from 'node:test';import assert from 'node:assert/strict';import {dashboardView} from '../platform/dashboard.mjs';
const esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const props={items:[],files:[],settings:{businessType:'trucking',taxReserve:25},company:'Synthetic Business',month:'2026-11',today:'2026-11-04',esc,period:'',canWrite:()=>true,finance:true,role:'owner'};
test('overview preserves earned profit and separates scheduled load pay',()=>{const html=dashboardView({...props,items:[{id:'a',kind:'load',payload:{description:'Earned',date:'2026-11-03',status:'completed',amount:1000,loadShare:88}},{id:'b',kind:'load',payload:{description:'Next',date:'2026-11-05',pickupDate:'2026-11-04',status:'scheduled',amount:2000,loadShare:88}},{id:'c',kind:'expense',payload:{description:'Cost',date:'2026-11-03',amount:100}}]});assert.match(html,/\$780\.00/);assert.match(html,/\$1,760\.00/);assert.match(html,/Scheduled load pay · not yet earned/);assert.match(html,/\$195\.00/);});
test('business mode shows remaining invoice and bill amounts after installments',()=>{const html=dashboardView({...props,settings:{businessType:'services'},items:[{id:'i',kind:'invoice',payload:{amount:500,paidAmount:100,status:'partial'}},{id:'b',kind:'bill',payload:{amount:200,paidAmount:50,status:'partial'}}]});assert.match(html,/\$400\.00/);assert.match(html,/\$150\.00/);assert.doesNotMatch(html,/Your next loads/);});
test('dashboard escapes company and record labels, ignores archived work',()=>{const html=dashboardView({...props,company:'<script>bad</script>',items:[{id:'a',kind:'load',archived_at:'2026-11-04',payload:{description:'Archived work',status:'scheduled',amount:500}},{id:'b',kind:'expense',payload:{description:'<img src=x>',date:'2026-11-04',amount:10}}]});assert.match(html,/&lt;script&gt;/);assert.match(html,/&lt;img src=x&gt;/);assert.doesNotMatch(html,/Archived work/);});

test('gross periods distinguish full load rate from earned share and exclude scheduled, archived and future records',async()=>{
 const {grossPeriods}=await import('../platform/dashboard.mjs');
 const row=(date,amount,kind='load',status='completed',extra={})=>({kind,payload:{date,amount,status,loadShare:88,...extra}});
 const rows=[row('2026-11-03',2550),row('2026-11-02',100,'income','paid'),row('2026-11-01',200),row('2026-01-01',300),row('2025-12-31',900),row('2026-11-04',900,'load','scheduled'),row('2026-11-05',900),{...row('2026-11-03',900),archived_at:'yes'},row('2026-11-03',900,'invoice','paid'),row('2026-11-03',900,'contribution','paid'),row('2026-11-03',900,'income','scheduled')];
 const result=grossPeriods(rows,{},'2026-11-04');
 assert.deepEqual(result.map(r=>r.gross),[2650,2850,3150]);assert.equal(result[0].companyRevenue,2344);assert.equal(result[0].start,'2026-11-02');
 assert.equal(grossPeriods([row('2025-12-29',10),row('2026-01-01',20)],{},'2026-01-01')[0].gross,30);
 assert.equal(grossPeriods([row('2026-11-01',10)],{},'2026-11-01')[0].start,'2026-10-26');
});
