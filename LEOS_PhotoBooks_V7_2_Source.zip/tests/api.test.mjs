// Exercise the actual Edge handler with an isolated, non-network database adapter.
// Real database RLS is independently exercised by isolation.sql.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {stripTypeScriptTypes} from 'node:module';
const owner='11111111-1111-4111-8111-111111111111';
const companyA='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const companyB='bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
let role='owner',verified=true,mutations=[];
const db={auth:{getUser:async token=>token==='valid-test-token'?{data:{user:{id:owner,email:'qa@example.invalid',email_confirmed_at:verified?'2026-01-01':null}},error:null}:{data:{user:null},error:{message:'Invalid'}}},from(table){
 const clauses=[];let operation='select';
 const query={select(){return query;},eq(k,v){clauses.push([k,v]);return query;},maybeSingle(){return query;},single(){return query;},is(){return query;},order(){return query;},range(){return query;},limit(){return query;},insert(){operation='insert';return query;},update(){operation='update';return query;},delete(){operation='delete';return query;},then(resolve){
  if(operation!=='select')mutations.push({table,operation});
  const cid=clauses.find(([k])=>k==='company_id')?.[1]||clauses.find(([k])=>k==='id')?.[1];
  let data=null;
  if(table==='leos_company_members'&&cid===companyA&&clauses.some(([k,v])=>k==='user_id'&&v===owner))data={role};
  if(table==='leos_companies'&&cid===companyA)data={id:companyA,name:'Test Company',plan:'preview',subscription_status:'preview'};
  return Promise.resolve({data,error:null}).then(resolve);
 }};return query;
}};
const dir=await mkdtemp(join(tmpdir(),'leos-api-'));
let source=await readFile(new URL('../supabase/functions/leos-platform/index.ts',import.meta.url),'utf8');
source=source.replace(/^import \{createClient\}.*\n/m,'').replace(/^const db=.*\n/m,'const db=globalThis.__leosIsolatedDb;\n').replace("from './policy.mjs'","from '"+new URL('../supabase/functions/leos-platform/policy.mjs',import.meta.url).href+"'").replace('Deno.serve(handler);','');
globalThis.__leosIsolatedDb=db;globalThis.Deno={env:{get:()=>undefined}};
await writeFile(join(dir,'handler.mjs'),stripTypeScriptTypes(source));
const {handler}=await import(pathToFileURL(join(dir,'handler.mjs')).href);
const request=(body,token='valid-test-token',origin='https://leos-photobooks.onrender.com')=>new Request('https://example.invalid/api',{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),Origin:origin},body:JSON.stringify(body)});
test('Edge API rejects unauthenticated, expired and unverified sessions',async()=>{
 assert.equal((await handler(request({action:'bootstrap'},''))).status,401);
 assert.equal((await handler(request({action:'bootstrap'},'expired-test-token'))).status,401);
 verified=false;assert.equal((await handler(request({action:'create_company',name:'Test'}))).status,403);verified=true;
});
test('every company route rejects a different tenant before data access or mutations',async()=>{
 for(const action of ['company_state','save_item','file_url','export','update_company','create_invite','change_role','remove_member','import_legacy','billing_portal','checkout','upload_file','record_payment']){
  const response=await handler(request({action,companyId:companyB}));assert.equal(response.status,403,action);
 }
 assert.equal(mutations.length,0);
});
test('drivers cannot create loads, change company settings, invite team, export or manage billing',async()=>{
 role='driver';
 for(const body of [{action:'save_item',kind:'load',payload:{description:'Test'}},{action:'update_company'},{action:'create_invite'},{action:'export'},{action:'billing_portal'},{action:'change_role'},{action:'record_payment'}]){
  const response=await handler(request({...body,companyId:companyA}));assert.equal(response.status,403,body.action);
 }
 role='owner';assert.equal(mutations.length,0);
});
test('cross-origin requests are rejected and unconfigured billing fails closed',async()=>{
 assert.equal((await handler(request({action:'health'},'', 'https://untrusted.invalid'))).status,403);
 const response=await handler(request({action:'checkout',companyId:companyA,plan:'solo',interval:'monthly'}));assert.equal(response.status,503);assert.equal(mutations.length,0);
});
test.after(async()=>{delete globalThis.__leosIsolatedDb;delete globalThis.Deno;await rm(dir,{recursive:true,force:true});});
