import test from 'node:test';
import assert from 'node:assert/strict';
import {extractBol,fuelBudget,rankQuotes,checkpoints} from '../platform/trip-domain.mjs';
test('OCR extracts draft blocks, never manufactures missing values',()=>{assert.equal(extractBol('Unknown document').origin,'');const d=extractBol('BOL # ABC123\nShip From\n123 Main St\nDallas TX\nShip To\n456 Oak St');assert.equal(d.loadNo,'ABC123');assert.equal(d.origin,'123 Main St, Dallas TX');assert.match(d.destination,/456 Oak/);});
test('fuel reserve and trip purchase reflect current fuel',()=>{assert.deepEqual(fuelBudget({miles:600,mpg:6,tank:200,current:80,reserve:20}),{gallons:100,range:360,purchase:40});assert.throws(()=>fuelBudget({miles:600,mpg:6,tank:100,current:150,reserve:20}));});
test('lower pump price can lose after detour cost',()=>{const a=rankQuotes([{station:'near',price:3.5,detour:0},{station:'far',price:3.4,detour:100}],50,6);assert.equal(a[0].station,'near');});
test('checkpoint arrival follows elapsed driving time with exact endpoints',()=>{const route={coordinates:[[30,-90],[30,-89],[30,-80]],seconds:36000};const d='2026-11-03T12:00:00Z';const pts=checkpoints(route,d);assert.equal(pts.length,5);assert.equal(pts[0].lng,-90);assert.equal(pts[4].lng,-80);assert.equal(pts[4].arrival,Date.parse(d)+36000000);});
