-- Additive V7 platform. Existing leos_* records and storage objects are unchanged.
create schema if not exists leos_private;
revoke all on schema leos_private from public, anon;
grant usage on schema leos_private to authenticated, service_role;

create table public.leos_companies (
 id uuid primary key default gen_random_uuid(), name text not null check(length(name) between 2 and 90),
 created_by uuid not null references auth.users(id), created_at timestamptz not null default now(),
 settings jsonb not null default '{}', plan text not null default 'preview' check(plan in ('preview','solo','small_fleet','fleet')),
 subscription_status text not null default 'preview', stripe_customer_id text unique, stripe_subscription_id text unique,
 current_period_end timestamptz, cancel_at_period_end boolean not null default false,
 billing_synced_at timestamptz, suspended boolean not null default false
);
create table public.leos_company_members (
 company_id uuid not null references public.leos_companies(id), user_id uuid not null references auth.users(id),
 role text not null check(role in ('owner','admin','dispatcher','driver','bookkeeper')),
 email text not null, joined_at timestamptz not null default now(), primary key(company_id,user_id)
);
create unique index leos_one_company_owner on public.leos_company_members(company_id) where role='owner';
create index leos_members_user on public.leos_company_members(user_id);
create table public.leos_company_invites (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.leos_companies(id),
 email text not null, role text not null check(role in ('admin','dispatcher','driver','bookkeeper')),
 token_hash text not null unique, created_by uuid not null references auth.users(id),
 created_at timestamptz not null default now(), expires_at timestamptz not null default (now()+interval '7 days'),
 accepted_at timestamptz, revoked_at timestamptz
);
create index leos_invites_company on public.leos_company_invites(company_id);
create table public.leos_company_items (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.leos_companies(id),
 kind text not null check(kind in ('load','fuel','expense','fee','settlement','draw','taxPayment','truck','maintenance','inspection','reminder')),
 payload jsonb not null default '{}', created_by uuid not null references auth.users(id),
 assigned_to uuid references auth.users(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 archived_at timestamptz, version integer not null default 1,
 legacy_user_id uuid, legacy_id text,
 unique(company_id,legacy_user_id,legacy_id)
);
create index leos_items_company on public.leos_company_items(company_id,created_at desc,id);
create index leos_items_assignee on public.leos_company_items(assigned_to);
create table public.leos_company_files (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.leos_companies(id),
 item_id uuid references public.leos_company_items(id), uploaded_by uuid not null references auth.users(id),
 bucket text not null, path text not null, name text not null, mime text, size bigint,
 created_at timestamptz not null default now(), unique(company_id,bucket,path)
);
create index leos_files_company on public.leos_company_files(company_id,item_id);
create table public.leos_company_audit (
 id bigint generated always as identity primary key, company_id uuid not null references public.leos_companies(id),
 actor_id uuid references auth.users(id), action text not null, detail jsonb not null default '{}', created_at timestamptz not null default now()
);
create index leos_audit_company on public.leos_company_audit(company_id,created_at desc);
create table public.leos_platform_admins (user_id uuid primary key references auth.users(id));
create table public.leos_billing_events (id text primary key, company_id uuid references public.leos_companies(id), processed_at timestamptz not null default now());

-- Helpers live outside exposed schemas and explicitly check the authenticated identity.
create function leos_private.company_role(cid uuid) returns text language sql stable security definer set search_path='' as $$
 select role from public.leos_company_members where company_id=cid and user_id=(select auth.uid())
$$;
revoke all on function leos_private.company_role(uuid) from public,anon;
grant execute on function leos_private.company_role(uuid) to authenticated;
create function leos_private.visible_item(cid uuid, creator uuid, assignee uuid) returns boolean language sql stable security invoker set search_path='' as $$
 select leos_private.company_role(cid) in ('owner','admin','dispatcher','bookkeeper')
 or (leos_private.company_role(cid)='driver' and ((select auth.uid())=creator or (select auth.uid())=assignee))
$$;
revoke all on function leos_private.visible_item(uuid,uuid,uuid) from public,anon;
grant execute on function leos_private.visible_item(uuid,uuid,uuid) to authenticated;

alter table public.leos_companies enable row level security;
alter table public.leos_company_members enable row level security;
alter table public.leos_company_invites enable row level security;
alter table public.leos_company_items enable row level security;
alter table public.leos_company_files enable row level security;
alter table public.leos_company_audit enable row level security;
alter table public.leos_platform_admins enable row level security;
alter table public.leos_billing_events enable row level security;
-- All mutations go through the authenticated Edge API. Browser clients cannot change roles or billing.
revoke all on public.leos_companies,public.leos_company_members,public.leos_company_invites,public.leos_company_items,public.leos_company_files,public.leos_company_audit,public.leos_platform_admins,public.leos_billing_events from anon,authenticated;
grant select on public.leos_companies,public.leos_company_members,public.leos_company_items,public.leos_company_files,public.leos_company_audit to authenticated;
grant all on public.leos_companies,public.leos_company_members,public.leos_company_invites,public.leos_company_items,public.leos_company_files,public.leos_company_audit,public.leos_platform_admins,public.leos_billing_events to service_role;
grant usage,select on sequence public.leos_company_audit_id_seq to service_role;
create policy company_read on public.leos_companies for select to authenticated using(leos_private.company_role(id) is not null);
create policy member_read on public.leos_company_members for select to authenticated using(user_id=(select auth.uid()) or leos_private.company_role(company_id) in ('owner','admin'));
create policy item_read on public.leos_company_items for select to authenticated using(leos_private.visible_item(company_id,created_by,assigned_to));
create policy file_read on public.leos_company_files for select to authenticated using(
 leos_private.company_role(company_id) in ('owner','admin','dispatcher','bookkeeper') or
 (leos_private.company_role(company_id)='driver' and (uploaded_by=(select auth.uid()) or exists(select 1 from public.leos_company_items i where i.id=item_id and i.company_id=leos_company_files.company_id and leos_private.visible_item(i.company_id,i.created_by,i.assigned_to))))
);
create policy audit_read on public.leos_company_audit for select to authenticated using(leos_private.company_role(company_id) in ('owner','admin'));

-- Atomic creation and seat/truck limits (not just a check in the browser).
create function leos_private.company_created() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 perform pg_advisory_xact_lock(hashtext(new.created_by::text));
 if (select count(*) from public.leos_companies where created_by=new.created_by)>3 then raise exception 'Company limit reached (3 per owner).'; end if;
 insert into public.leos_company_members(company_id,user_id,role,email)
 values(new.id,new.created_by,'owner','');
 return new;
end $$;
create trigger leos_company_created after insert on public.leos_companies for each row execute function leos_private.company_created();
create function leos_private.member_limit() returns trigger language plpgsql security invoker set search_path='' as $$
declare p text; lim int;
begin
 select plan into p from public.leos_companies where id=new.company_id for update;
 lim:=case p when 'solo' then 1 when 'small_fleet' then 10 when 'fleet' then 50 else 10 end;
 if (select count(*) from public.leos_company_members where company_id=new.company_id)>=lim then raise exception 'Team member limit reached for this plan.'; end if;
 return new;
end $$;
create trigger leos_member_limit before insert on public.leos_company_members for each row execute function leos_private.member_limit();
create function leos_private.truck_limit() returns trigger language plpgsql security invoker set search_path='' as $$
declare p text; lim int;
begin
 if new.kind='truck' and new.archived_at is null and (tg_op='INSERT' or old.archived_at is not null) then
  select plan into p from public.leos_companies where id=new.company_id for update;
  lim:=case p when 'solo' then 1 when 'small_fleet' then 5 else 25 end;
  if (select count(*) from public.leos_company_items where company_id=new.company_id and kind='truck' and archived_at is null)>=lim then raise exception 'Truck limit reached for this plan.'; end if;
 end if;
 return new;
end $$;
create trigger leos_truck_limit before insert or update on public.leos_company_items for each row execute function leos_private.truck_limit();

-- Service-only transactional invite acceptance. No privileged public-callable RPC.
create function public.leos_accept_company_invite(token_digest text, member_id uuid, member_email text) returns uuid language plpgsql security invoker set search_path='' as $$
declare inv public.leos_company_invites; cid uuid;
begin
 select * into inv from public.leos_company_invites where token_hash=token_digest for update;
 if inv.id is null or inv.revoked_at is not null or inv.accepted_at is not null or inv.expires_at<now() then raise exception 'Invitation has expired or is no longer available.'; end if;
 if lower(inv.email)<>lower(member_email) then raise exception 'Sign in with the email address this invitation was sent to.'; end if;
 if exists(select 1 from public.leos_company_members where company_id=inv.company_id and user_id=member_id) then raise exception 'You already belong to this company.'; end if;
 insert into public.leos_company_members(company_id,user_id,role,email) values(inv.company_id,member_id,inv.role,lower(member_email));
 update public.leos_company_invites set accepted_at=now() where id=inv.id;
 insert into public.leos_company_audit(company_id,actor_id,action,detail) values(inv.company_id,member_id,'member.joined',jsonb_build_object('role',inv.role));
 return inv.company_id;
end $$;
revoke all on function public.leos_accept_company_invite(text,uuid,text) from public,anon,authenticated;
grant execute on function public.leos_accept_company_invite(text,uuid,text) to service_role;

create function public.leos_sync_subscription(event_id text,cid uuid,customer text,subscription text,new_plan text,new_status text,period_end timestamptz,canceling boolean,sync_time timestamptz) returns boolean language plpgsql security invoker set search_path='' as $$
begin
 insert into public.leos_billing_events(id,company_id) values(event_id,cid) on conflict do nothing;
 if not found then return false; end if;
 update public.leos_companies set stripe_customer_id=customer,stripe_subscription_id=subscription,plan=new_plan,subscription_status=new_status,current_period_end=period_end,cancel_at_period_end=canceling,billing_synced_at=sync_time where id=cid and (billing_synced_at is null or billing_synced_at<=sync_time);
 return true;
end $$;
revoke all on function public.leos_sync_subscription(text,uuid,text,text,text,text,timestamptz,boolean,timestamptz) from public,anon,authenticated;
grant execute on function public.leos_sync_subscription(text,uuid,text,text,text,text,timestamptz,boolean,timestamptz) to service_role;
-- This bucket has no public read/write policies. The Edge API issues short-lived signed URLs after authorization.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('leos-company-documents','leos-company-documents',false,10485760,array['application/pdf','image/jpeg','image/png','image/webp']) on conflict(id) do nothing;
-- Keep implementation functions inaccessible to API callers.
revoke all on function leos_private.company_created(),leos_private.member_limit(),leos_private.truck_limit() from public,anon,authenticated;
