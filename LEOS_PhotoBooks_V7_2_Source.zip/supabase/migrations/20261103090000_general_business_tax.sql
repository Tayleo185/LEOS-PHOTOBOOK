-- Extend supported records. Existing rows and receipt objects stay unchanged.
alter table public.leos_company_items drop constraint leos_company_items_kind_check;
alter table public.leos_company_items add constraint leos_company_items_kind_check check(kind in ('load','fuel','expense','fee','settlement','draw','taxPayment','truck','maintenance','inspection','reminder','income','invoice','bill','contribution','taxDeadline'));
alter table public.leos_company_members drop constraint leos_company_members_role_check;
alter table public.leos_company_members add constraint leos_company_members_role_check check(role in ('owner','admin','dispatcher','driver','staff','bookkeeper'));
alter table public.leos_company_invites drop constraint leos_company_invites_role_check;
alter table public.leos_company_invites add constraint leos_company_invites_role_check check(role in ('admin','dispatcher','driver','staff','bookkeeper'));
create or replace function leos_private.visible_item(cid uuid, creator uuid, assignee uuid) returns boolean language sql stable security invoker set search_path='' as $$
 select leos_private.company_role(cid) in ('owner','admin','dispatcher','bookkeeper')
 or (leos_private.company_role(cid) in ('driver','staff') and ((select auth.uid())=creator or (select auth.uid())=assignee))
$$;
alter policy item_read on public.leos_company_items using(
 leos_private.visible_item(company_id,created_by,assigned_to)
 and (kind not in ('taxPayment','taxDeadline') or leos_private.company_role(company_id) in ('owner','admin','bookkeeper'))
);
create function leos_private.can_read_company_file(cid uuid,iid uuid,uploader uuid) returns boolean language plpgsql stable security definer set search_path='' as $$
declare r text; i public.leos_company_items;
begin
 if auth.uid() is null then return false; end if;
 r:=leos_private.company_role(cid);
 if r is null then return false; end if;
 if r in ('owner','admin','bookkeeper') then return true; end if;
 if iid is not null then
  select * into i from public.leos_company_items where id=iid and company_id=cid;
  if i.id is null or i.kind in ('taxPayment','taxDeadline') then return false; end if;
 end if;
 if r='dispatcher' then return true; end if;
 return r in ('driver','staff') and (uploader=auth.uid() or i.created_by=auth.uid() or i.assigned_to=auth.uid());
end $$;
revoke all on function leos_private.can_read_company_file(uuid,uuid,uuid) from public,anon;
grant execute on function leos_private.can_read_company_file(uuid,uuid,uuid) to authenticated;
alter policy file_read on public.leos_company_files using(leos_private.can_read_company_file(company_id,item_id,uploaded_by));
create unique index leos_one_invoice_receipt on public.leos_company_items(company_id,(payload->>'invoiceId')) where kind='income' and payload ? 'invoiceId';
create unique index leos_one_bill_payment on public.leos_company_items(company_id,(payload->>'billId')) where kind='expense' and payload ? 'billId';

-- Atomic full-payment recording. Privileges are restricted to the service API.
create function public.leos_record_business_payment(cid uuid,item uuid,actor uuid,payment_date date,expected_version integer)
returns uuid language plpgsql security invoker set search_path='' as $$
declare original public.leos_company_items; receipt_id uuid; receipt_kind text; link_key text;
begin
 select * into original from public.leos_company_items where company_id=cid and id=item and archived_at is null for update;
 if original.id is null or original.kind not in ('invoice','bill') then raise exception 'Invoice or bill not found.'; end if;
 receipt_kind:=case original.kind when 'invoice' then 'income' else 'expense' end;
 link_key:=case original.kind when 'invoice' then 'invoiceId' else 'billId' end;
 select id into receipt_id from public.leos_company_items where company_id=cid and kind=receipt_kind and payload->>link_key=item::text;
 if receipt_id is not null then return receipt_id; end if;
 if original.version<>expected_version then raise exception 'This record changed. Refresh before recording payment.'; end if;
 if original.payload->>'status'='paid' then raise exception 'This record is already marked paid.'; end if;
 if coalesce((original.payload->>'amount')::numeric,0)<=0 then raise exception 'Enter a positive amount before recording payment.'; end if;
 receipt_id:=gen_random_uuid();
 insert into public.leos_company_items(id,company_id,kind,created_by,payload)
 values(receipt_id,cid,receipt_kind,actor,original.payload||jsonb_build_object(link_key,item::text,'date',payment_date::text,'status','paid','description',case original.kind when 'invoice' then 'Payment received: ' else 'Bill paid: ' end||(original.payload->>'description'),'paidBy','company'));
 update public.leos_company_items set payload=payload||'{"status":"paid"}'::jsonb,version=version+1,updated_at=now() where id=item;
 insert into public.leos_company_audit(company_id,actor_id,action,detail) values(cid,actor,'payment.recorded',jsonb_build_object('sourceId',item,'receiptId',receipt_id,'kind',original.kind));
 return receipt_id;
end $$;
revoke all on function public.leos_record_business_payment(uuid,uuid,uuid,date,integer) from public,anon,authenticated;
grant execute on function public.leos_record_business_payment(uuid,uuid,uuid,date,integer) to service_role;
