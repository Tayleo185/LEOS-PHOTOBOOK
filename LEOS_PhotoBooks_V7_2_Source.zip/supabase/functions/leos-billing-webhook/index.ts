import Stripe from 'npm:stripe@23.1.0';
import {createClient} from 'npm:@supabase/supabase-js@2.118.0';
const db=createClient(Deno.env.get('SUPABASE_URL')!,JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')||'{}').default||Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
Deno.serve(async(req:Request)=>{
 const headers={'Content-Type':'application/json','Cache-Control':'no-store'};
 const reply=(message:string,status=200)=>new Response(JSON.stringify({message}),{status,headers});
 if(req.method!=='POST')return reply('Use POST.',405);
 const key=Deno.env.get('STRIPE_SECRET_KEY'),secret=Deno.env.get('STRIPE_WEBHOOK_SECRET');
 if(!key||!secret)return reply('Billing is not configured.',503);
 const stripe=new Stripe(key,{apiVersion:'2026-10-28.endive',httpClient:Stripe.createFetchHttpClient()});
 let event:Stripe.Event;
 try{event=await stripe.webhooks.constructEventAsync(await req.text(),req.headers.get('stripe-signature')||'',secret,undefined,Stripe.createSubtleCryptoProvider());}
 catch{return reply('Invalid signature.',400);}
 try{
  let subscriptionId:string|undefined;
  const obj:any=event.data.object;
  if(event.type.startsWith('customer.subscription.'))subscriptionId=obj.id;
  else if(event.type==='checkout.session.completed')subscriptionId=typeof obj.subscription==='string'?obj.subscription:obj.subscription?.id;
  else if(event.type==='invoice.paid'||event.type==='invoice.payment_failed')subscriptionId=typeof obj.parent?.subscription_details?.subscription==='string'?obj.parent.subscription_details.subscription:obj.subscription;
  else return reply('Ignored.');
  if(!subscriptionId)return reply('No subscription.');
  // Retrieve current provider state, rather than trusting delivery order or the success redirect.
  const syncedAt=new Date().toISOString();
  const subscription=await stripe.subscriptions.retrieve(subscriptionId);
  const cid=subscription.metadata.company_id;
  if(!cid)return reply('Missing company metadata.',400);
  const {data:company,error}=await db.from('leos_companies').select('id,stripe_customer_id,stripe_subscription_id').eq('id',cid).single();
  if(error||!company)return reply('Company not found.',400);
  const customer=typeof subscription.customer==='string'?subscription.customer:subscription.customer.id;
  if(company.stripe_customer_id!==customer)return reply('Customer mismatch.',400);
  if(company.stripe_subscription_id&&company.stripe_subscription_id!==subscription.id){
   const prior=await stripe.subscriptions.retrieve(company.stripe_subscription_id);
   if(!['canceled','incomplete_expired'].includes(prior.status))return reply('Another subscription is already attached.',409);
  }
  const price=subscription.items.data[0]?.price.id;
  const plan=['solo','small_fleet','fleet'].find(p=>['monthly','yearly'].some(i=>Deno.env.get(`STRIPE_PRICE_${p.toUpperCase()}_${i.toUpperCase()}`)===price));
  if(!plan)return reply('Unrecognized subscription price.',400);
  const end=subscription.items.data[0]?.current_period_end;
  const result=await db.rpc('leos_sync_subscription',{event_id:event.id,cid,customer,subscription:subscription.id,new_plan:plan,new_status:subscription.status,period_end:end?new Date(end*1000).toISOString():null,canceling:subscription.cancel_at_period_end,sync_time:syncedAt});
  if(result.error)throw result.error;
  return reply('Processed.');
 }catch(error:any){console.error('Billing sync failed',error.code||'provider_error');return reply('Retry required.',500);}
});
