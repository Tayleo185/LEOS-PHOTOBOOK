
const allowedOrigins=new Set(["https://leos-photobooks.onrender.com","http://terminal.local:4173"]);
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST,OPTIONS"};
function reply(body,status=200){return new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json","Cache-Control":"no-store"}});}
function err(message,status=400,code="REQUEST_ERROR"){return reply({error:message,code},status);}
const validNumber=(n,min,max)=>Number.isFinite(Number(n))&&Number(n)>=min&&Number(n)<=max;
const km=meters=>Math.round(meters/1609.344*10)/10;
const chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
function decodeFlexiblePolyline(value){
 if(!value||value.length>120000)return [];
 let index=0;const read=()=>{let result=0,shift=0,next;do{if(index>=value.length)throw Error("Invalid geometry");const a=chars.indexOf(value[index++]);if(a<0)throw Error("Invalid geometry");result+=(a&31)*Math.pow(2,shift);next=a&32;shift+=5;if(shift>55)throw Error("Invalid geometry");}while(next);return result;};
 const version=read(),header=read();if(version!==1)throw Error("Unsupported geometry");
 const scale=Math.pow(10,header&15),third=(header>>4)&7,thirdScale=Math.pow(10,(header>>7)&15);
 let lat=0,lng=0,z=0;const points=[];
 const sign=v=>v%2===1?-(v+1)/2:v/2;
 while(index<value.length&&points.length<20000){
  lat+=sign(read());lng+=sign(read());if(third)z+=sign(read());
  points.push([Math.round(lat/scale*1e6)/1e6,Math.round(lng/scale*1e6)/1e6]);
 }
 return points;
}
async function hereGeocode(address,key){
 const u=new URL("https://geocode.search.hereapi.com/v1/geocode");
 u.searchParams.set("q",address);u.searchParams.set("limit","3");u.searchParams.set("apiKey",key);
 const r=await fetch(u.toString(),{signal:AbortSignal.timeout(12000)});
 if(!r.ok)throw Error("Truck routing provider could not geocode an address ("+r.status+").");
 const j=await r.json();const place=(j.items||[]).find(i=>i.position&&["houseNumber","street","place"].includes(i.resultType));
 if(!place)throw Error("Cannot locate address: "+address+". Review the BOL address.");
 return {lat:place.position.lat,lng:place.position.lng,label:place.address?.label||address,matchType:place.resultType||"unknown"};
}
Deno.serve(async req=>{
 if(req.headers.get("Origin")&&!allowedOrigins.has(req.headers.get("Origin")))return err("Origin not allowed",403);
 if(req.method==="OPTIONS")return new Response(null,{headers:cors});
 if(req.method!=="POST")return err("POST required",405);
 try{
  const bearer=req.headers.get("Authorization")||"";
  if(!bearer.startsWith("Bearer "))return err("Sign in to plan your private truck route.",401,"NOT_SIGNED_IN");
  const url=Deno.env.get("SUPABASE_URL");const keys=JSON.parse(Deno.env.get("SUPABASE_PUBLISHABLE_KEYS")||"{}");
  const publishable=keys.default||Deno.env.get("SUPABASE_ANON_KEY");
  if(!url||!publishable)return err("Account verification is not configured.",503,"AUTH_NOT_CONFIGURED");
  const identity=await fetch(url+"/auth/v1/user",{headers:{Authorization:bearer,apikey:publishable},signal:AbortSignal.timeout(10000)});
  if(!identity.ok)return err("Session expired. Please sign in again.",401,"NOT_SIGNED_IN");
  const user=await identity.json();
  if(!user.id||!user.email_confirmed_at)return err("Verify your email before accessing routing.",403,"EMAIL_NOT_VERIFIED");
  if(Number(req.headers.get("Content-Length")||0)>20000)return err("Request too large",413);
  const input=await req.json();
  if(!input||typeof input!=="object"||Array.isArray(input))return err("Invalid request");
  if(input.action==="capabilities")return reply({routing:!!Deno.env.get("HERE_API_KEY"),weather:true,fuelPrices:false,loadBoard:false});
  if(input.action==="weather"){
    const points=input.points;
    if(!Array.isArray(points)||!points.length||points.length>5)return err("Choose 1–5 route checkpoints.");
    const results=await Promise.all(points.map(async(p)=>{
      if(!validNumber(p.lat,-90,90)||!validNumber(p.lng,-180,180))return {error:"Invalid checkpoint"};
      const lat=Number(p.lat).toFixed(4),lng=Number(p.lng).toFixed(4);
      const headers={"Accept":"application/geo+json","User-Agent":"LEOSPhotoBooks/7.2 (leos-photobooks.onrender.com)"};
      const get=async(url)=>{const r=await fetch(url,{headers,signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error("Weather unavailable ("+r.status+")");return r.json();};
      try{
        const grid=await get("https://api.weather.gov/points/"+lat+","+lng);
        const forecastUrl=grid.properties?.forecastHourly;
        if(!forecastUrl?.startsWith("https://api.weather.gov/"))throw Error("Hourly forecast unavailable");
        const [forecast,alerts]=await Promise.allSettled([get(forecastUrl),get("https://api.weather.gov/alerts/active?point="+lat+","+lng)]);
        const periods=forecast.status==="fulfilled"?(forecast.value.properties?.periods||[]):[];
        const at=Number(p.arrival);
        const period=periods.find(x=>at>=Date.parse(x.startTime)&&at<Date.parse(x.endTime));
        return {lat:Number(lat),lng:Number(lng),arrival:Number.isFinite(at)?new Date(at).toISOString():null,
          place:grid.properties?.relativeLocation?.properties?.city||lat+","+lng,
          updated:forecast.status==="fulfilled"?forecast.value.properties?.updateTime:null,
          forecast:period?{startTime:period.startTime,shortForecast:period.shortForecast,temperature:period.temperature,temperatureUnit:period.temperatureUnit,windSpeed:period.windSpeed,windDirection:period.windDirection}:null,
          alerts:alerts.status==="fulfilled"?(alerts.value.features||[]).slice(0,8).map(a=>({event:a.properties.event,severity:a.properties.severity,headline:a.properties.headline,expires:a.properties.expires,description:a.properties.description})):[],
          alertsError:alerts.status==="rejected"?"Active alerts unavailable":null,
          error:!period?"No hourly forecast covering estimated arrival":null};
      }catch(e){return {lat:Number(lat),lng:Number(lng),error:String(e.message).slice(0,140)};}
    }));
    return reply({provider:"National Weather Service",checkedAt:new Date().toISOString(),checkpoints:results});
  }
  const key=Deno.env.get("HERE_API_KEY");
  if(!key)return err("Commercial truck routing is not activated yet. An administrator must add a HERE API key securely in Supabase Edge Function secrets.",503,"ROUTING_NOT_CONFIGURED");
  if(input.hazmat||input.permitLoad)return err("Hazmat and permit loads require a specialist route review; automated routing is unavailable.",422);
  const origin=String(input.origin||"").trim(),destination=String(input.destination||"").trim();
  if(origin.length<7||origin.length>240||destination.length<7||destination.length>240)return err("Provide verified pickup and delivery street addresses.");
  const heightFt=Number(input.heightFeet),loadedLb=Number(input.weightLb),totalLengthFt=Number(input.combinedLengthFeet||0);
  if(!validNumber(heightFt,6,17)||!validNumber(loadedLb,10000,200000))return err("Confirm truck height and current gross combination weight.");
  if(!validNumber(totalLengthFt,20,150))return err("Confirm total tractor-and-trailer length, not trailer length alone.");
  if(!validNumber(input.widthFeet,3,12))return err("Confirm overall vehicle width.");
  const pickup=await hereGeocode(origin,key),delivery=await hereGeocode(destination,key);
  const u=new URL("https://router.hereapi.com/v8/routes");
  u.searchParams.set("transportMode","truck");u.searchParams.set("origin",pickup.lat+","+pickup.lng);
  u.searchParams.set("destination",delivery.lat+","+delivery.lng);u.searchParams.set("routingMode","fast");
  u.searchParams.set("alternatives","2");u.searchParams.set("return","summary,polyline,actions,instructions");
  u.searchParams.set("lang","en-US");u.searchParams.set("units","imperial");
  u.searchParams.set("vehicle[width]",String(Math.ceil(Number(input.widthFeet)*30.48)));
  u.searchParams.set("vehicle[height]",String(Math.ceil(heightFt*30.48)));
  u.searchParams.set("vehicle[currentWeight]",String(Math.ceil(loadedLb*0.45359237)));
  u.searchParams.set("vehicle[grossWeight]",String(Math.ceil(loadedLb*0.45359237)));
  u.searchParams.set("vehicle[trailerCount]","1");
  if(totalLengthFt)u.searchParams.set("vehicle[length]",String(Math.ceil(totalLengthFt*30.48)));
  if(input.departureTime){const dt=Date.parse(input.departureTime);if(!Number.isFinite(dt))return err("Invalid departure time");u.searchParams.set("departureTime",new Date(dt).toISOString());}
  u.searchParams.set("apiKey",key);
  const response=await fetch(u.toString(),{signal:AbortSignal.timeout(25000)});
  const result=await response.json().catch(()=>({}));
  if(!response.ok)return err("Truck routing provider error ("+response.status+"): "+String(result.title||result.cause||"Check routing configuration").slice(0,180),502,"PROVIDER_ERROR");
  const routes=(result.routes||[]).slice(0,3).map((r,i)=>{
    const sections=r.sections||[];
    const notices=[...(r.notices||[]),...sections.flatMap(s=>s.notices||[])].map(n=>({severity:n.severity||"info",code:n.code||"",title:n.title||""}));
    const points=sections.flatMap(s=>decodeFlexiblePolyline(s.polyline||""));
    const reduced=points.filter((p,j)=>j===0||j===points.length-1||j%Math.max(1,Math.ceil(points.length/1400))===0);
    return {
      id:i+1,label:i===0?"Recommended truck route":"Alternate truck route "+i,
      miles:km(sections.reduce((sum,s)=>sum+Number(s.summary?.length||0),0)),
      seconds:sections.reduce((sum,s)=>sum+Number(s.summary?.duration||0),0),
      coordinates:reduced,notices,
      critical:notices.some(n=>n.severity==="critical"),
      steps:sections.flatMap(s=>(s.actions||[]).map(a=>String(a.instruction||"").slice(0,240))).filter(Boolean).slice(0,160)
    };
  });
  if(!routes.length)return err("No route returned. Check pickup, delivery, size and weight.",422,"NO_ROUTE");
  return reply({provider:"HERE Routing API v8",routes,origin:pickup,destination:delivery,assumptions:{heightFt,loadedLb,totalLengthFt:totalLengthFt||null},fuelPricesIncluded:false,truckRestricted:true,disclaimer:"Review every critical notice, posted restriction, current weather and construction. Route is guidance, not a legal clearance guarantee."});
 }catch(e){return err(String(e?.message||e).slice(0,220),500,"ROUTE_ERROR");}
});

