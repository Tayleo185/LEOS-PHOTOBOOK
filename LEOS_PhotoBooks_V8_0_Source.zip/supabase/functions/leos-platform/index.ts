import {createClient} from 'npm:@supabase/supabase-js@2.118.0';
import {PLANS,ROLES,KINDS,fail,isManager,canReadItem,canWriteKind,writable,uuid,cleanPayload,validateAssignment,verifyFileSignature} from './policy.mjs';

const APP='https://leos-photobooks.onrender.com';
const db=createClient(Deno.env.get('SUPABASE_URL')!,JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')||'{}').default||Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
const financeRole=(role:string)=>['owner','admin','bookkeeper'].includes(role);
const taxKind=(kind:string)=>['taxPayment','taxDeadline'].includes(kind);
const now=()=>new Date().toISOString();
const checked=async(q:any)=>{const r=await q;if(r.error)throw r.error;return r.data;};
const priceKey=(plan:string,interval:string)=>`STRIPE_PRICE_${plan.toUpperCase()}_${interval.toUpperCase()}`;
function billingReady(){return !!(Deno.env.get('STRIPE_SECRET_KEY')&&Deno.env.get('STRIPE_WEBHOOK_SECRET')&&['solo','small_fleet','fleet'].some(p=>Deno.env.get(priceKey(p,'monthly'))));}
async function stripe(path:string,params?:URLSearchParams,key?:string){
 const secret=Deno.env.get('STRIPE_SECRET_KEY');if(!secret)fail('Subscription payments are not active yet.',503);
 const r=await fetch('https://api.stripe.com/v1/'+path,{method:params?'POST':'GET',headers:{Authorization:'Bearer '+secret,'Stripe-Version':'2026-10-28.endive',...(params?{'Content-Type':'application/x-www-form-urlencoded'}:{}),...(key?{'Idempotency-Key':key}:{})},body:params});
 const data=await r.json();if(!r.ok)fail('Billing provider could not complete the request. Please try again.',502);return data;
}
async function audit(company:string,user:string,action:string,detail={}){await checked(db.from('leos_company_audit').insert({company_id:company,actor_id:user,action,detail}));}
async function sha(value:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))),x=>x.toString(16).padStart(2,'0')).join('');}
function publicCompany(c:any){const {stripe_customer_id,stripe_subscription_id,billing_synced_at,...safe}=c;return safe;}
async function memberships(user:string){return await checked(db.from('leos_company_members').select('company_id,role,email,company:leos_companies(*)').eq('user_id',user));}
async function context(companyId:string,user:string){
 uuid(companyId);
 const m=await checked(db.from('leos_company_members').select('role').eq('company_id',companyId).eq('user_id',user).maybeSingle());if(!m)fail('This company is not available to your account.',403);
 const company=await checked(db.from('leos_companies').select('*').eq('id',companyId).single());return {role:m.role,company};
}
async function allRows(table:string,companyId:string,configure=(q:any)=>q){
 const rows=[];for(let page=0;page<100;page++){const data=await checked(configure(db.from(table).select('*').eq('company_id',companyId)).order('id').range(page*1000,page*1000+999));rows.push(...data);if(data.length<1000)return rows;}fail('Export is too large. Contact support.',413);
}
export async function handler(req:Request){
 const origin=req.headers.get('Origin')||'';
 const allowed=origin===APP||origin==='http://terminal.local:4173'||/^http:\/\/(localhost|127\.0\.0\.1):\d+$/.test(origin);
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin',...(allowed?{'Access-Control-Allow-Origin':origin}:{}),'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS'};
 const respond=(data:any,status=200)=>new Response(JSON.stringify(data),{status,headers});
 if(req.method==='OPTIONS')return new Response(null,{status:allowed?204:403,headers});
 if(origin&&!allowed)return respond({error:'Origin not allowed.'},403);
 if(req.method!=='POST')return respond({error:'Use POST.'},405);
 try{
  const length=Number(req.headers.get('Content-Length')||0);if(length>12*1024*1024)fail('Upload is too large.',413);
  const multipart=req.headers.get('Content-Type')?.includes('multipart/form-data');
  const form=multipart?await req.formData():null;
  const body:any=form?Object.fromEntries(form):await req.json();
  const action=body.action;
  if(action==='health')return respond({version:'7.1',billingReady:billingReady(),plans:PLANS});
  const token=(req.headers.get('Authorization')||'').replace(/^Bearer\s+/i,'');
  if(!token)fail('Sign in to continue.',401);
  const {data:auth,error:authError}=await db.auth.getUser(token);
  if(authError||!auth.user)fail('Your session has expired. Sign in again.',401);
  const user=auth.user;if(!user.email_confirmed_at)fail('Verify your email to use company workspaces.',403);
  if(action==='bootstrap'){
   const list=await memberships(user.id),admin=await checked(db.from('leos_platform_admins').select('user_id').eq('user_id',user.id).maybeSingle());
   return respond({companies:list.map((m:any)=>({...publicCompany(m.company),role:m.role})),platformAdmin:!!admin,billingReady:billingReady(),plans:PLANS});
  }
  if(action==='create_company'){
   const name=String(body.name||'').trim();if(name.length<2||name.length>90)fail('Company name must be 2–90 characters.');
   const businessType=['trucking','general','services','retail','projects'].includes(body.businessType)?body.businessType:'general';
   const company=await checked(db.from('leos_companies').insert({name,created_by:user.id,settings:{businessType}}).select().single());
   await checked(db.from('leos_company_members').update({email:user.email}).eq('company_id',company.id).eq('user_id',user.id));
   await audit(company.id,user.id,'company.created');return respond({company:publicCompany(company)});
  }
  if(action==='accept_invite'){
   const raw=String(body.token||'');if(!/^[a-f0-9]{64}$/.test(raw))fail('Invalid invitation link.');
   const cid=await checked(db.rpc('leos_accept_company_invite',{token_digest:await sha(raw),member_id:user.id,member_email:user.email}));return respond({companyId:cid});
  }
  if(action==='platform_overview'){
   const admin=await checked(db.from('leos_platform_admins').select('user_id').eq('user_id',user.id).maybeSingle());if(!admin)fail('Platform access required.',403);
   const companies=await checked(db.from('leos_companies').select('id,name,plan,subscription_status,created_at,suspended').order('created_at',{ascending:false}).limit(500));
   return respond({companies});
  }
  const cid=body.companyId;const {company,role}=await context(cid,user.id);
  if(action==='company_state'){
   let query=db.from('leos_company_items').select('*',{count:'exact'}).eq('company_id',cid).is('archived_at',null);
   if(!financeRole(role))query=query.not('kind','in','(taxPayment,taxDeadline)');
   if(['driver','staff'].includes(role))query=query.or(`created_by.eq.${user.id},assigned_to.eq.${user.id}`);
   const offset=Math.max(0,Math.floor(Number(body.offset)||0));
   const result=await query.order('created_at',{ascending:false}).order('id').range(offset,offset+999);if(result.error)throw result.error;
   const members=(isManager(role)||role==='dispatcher')?await checked(db.from('leos_company_members').select('user_id,email,role,joined_at').eq('company_id',cid).order('joined_at')):[];
   const invites=isManager(role)?await checked(db.from('leos_company_invites').select('id,email,role,created_at,expires_at,accepted_at,revoked_at').eq('company_id',cid).is('accepted_at',null).is('revoked_at',null).order('created_at',{ascending:false}).limit(100)):[];
   const files=await allRows('leos_company_files',cid);
   const readableFiles=files.filter((f:any)=>{const item=result.data.find((i:any)=>i.id===f.item_id);if(f.item_id&&!item&&!financeRole(role))return false;return !['driver','staff'].includes(role)||f.uploaded_by===user.id||!!item;});
   const auditLog=isManager(role)?await checked(db.from('leos_company_audit').select('id,action,detail,created_at').eq('company_id',cid).order('created_at',{ascending:false}).limit(20)):[];
   const trucks=await db.from('leos_company_items').select('id',{count:'exact',head:true}).eq('company_id',cid).eq('kind','truck').is('archived_at',null);
   const team=await db.from('leos_company_members').select('user_id',{count:'exact',head:true}).eq('company_id',cid);
   if(trucks.error||team.error)throw trucks.error||team.error;
   return respond({company:publicCompany(company),role,items:result.data,total:result.count,files:readableFiles,members,invites,audit:auditLog,usage:{trucks:trucks.count,members:team.count},billingReady:billingReady()});
  }
  if(action==='export'){
   if(['driver','staff'].includes(role))fail('Company export requires an owner, administrator, dispatcher or bookkeeper.',403);
   const items=await allRows('leos_company_items',cid,(q:any)=>financeRole(role)?q:q.not('kind','in','(taxPayment,taxDeadline)'));const allFiles=await allRows('leos_company_files',cid);const files=allFiles.filter((f:any)=>financeRole(role)||!f.item_id||items.some((i:any)=>i.id===f.item_id));
   await audit(cid,user.id,'company.exported');return respond({app:'LEOS PhotoBooks',version:'7.1',exportedAt:now(),company:publicCompany(company),items,files,note:'This export contains document references. Download original files separately from Documents.'});
  }
  if(action==='file_url'){
   const file=await checked(db.from('leos_company_files').select('*').eq('id',uuid(body.fileId)).eq('company_id',cid).maybeSingle());if(!file)fail('File not found.',404);
   const linked=file.item_id&&await checked(db.from('leos_company_items').select('*').eq('id',file.item_id).eq('company_id',cid).maybeSingle());
   if(file.item_id&&!linked)fail('Document not available.',404);
   if(linked&&taxKind(linked.kind)&&!financeRole(role))fail('Financial access required for tax documents.',403);
   if(['driver','staff'].includes(role)&&file.uploaded_by!==user.id&&(!linked||!canReadItem(role,user.id,linked)))fail('Document not available.',403);
   const data=await checked(db.storage.from(file.bucket).createSignedUrl(file.path,300));return respond({url:data.signedUrl});
  }
  if(action==='checkout'||action==='billing_portal'){
   if(role!=='owner')fail('Only the company owner can manage billing.',403);
   if(!billingReady())fail('Subscriptions are not active yet. Your early-access workspace is available without a payment.',503);
   let customer=company.stripe_customer_id;
   if(!customer){
    const r=await stripe('customers',new URLSearchParams({email:user.email!,name:company.name,'metadata[company_id]':cid}),`customer-${cid}`);customer=r.id;
    await checked(db.from('leos_companies').update({stripe_customer_id:customer}).eq('id',cid));
   }
   if(action==='billing_portal'){
    const portal=await stripe('billing_portal/sessions',new URLSearchParams({customer,return_url:APP+'/company.html#billing'}));return respond({url:portal.url});
   }
   if(company.stripe_subscription_id&&['active','trialing','past_due','unpaid','incomplete','paused'].includes(company.subscription_status))fail('Manage your existing subscription from the billing portal.',409);
   const plan=body.plan,interval=body.interval;
   if(!['solo','small_fleet','fleet'].includes(plan)||!['monthly','yearly'].includes(interval))fail('Choose a valid plan and billing interval.');
   const price=Deno.env.get(priceKey(plan,interval));if(!price)fail('This billing option is not available yet.',503);
   const [members,trucks]=await Promise.all([db.from('leos_company_members').select('*',{count:'exact',head:true}).eq('company_id',cid),db.from('leos_company_items').select('*',{count:'exact',head:true}).eq('company_id',cid).eq('kind','truck').is('archived_at',null)]);
   if(members.error||trucks.error)throw members.error||trucks.error;
   if(members.count!>PLANS[plan].members||trucks.count!>PLANS[plan].trucks)fail('Your team or trucks exceed this plan. Choose a larger plan.');
   const params=new URLSearchParams({mode:'subscription',customer,'line_items[0][price]':price,'line_items[0][quantity]':'1',client_reference_id:cid,'metadata[company_id]':cid,'subscription_data[metadata][company_id]':cid,success_url:APP+'/company.html?billing=success#billing',cancel_url:APP+'/company.html#billing',allow_promotion_codes:'true','subscription_data[billing_mode][type]':'flexible'});
   const session=await stripe('checkout/sessions',params,`checkout-${cid}-${plan}-${interval}-${Math.floor(Date.now()/1800000)}`);return respond({url:session.url});
  }
  // Read and export are always available; unpaid subscriptions only block mutations.
  writable(company);
  if(action==='update_company'){
   if(!isManager(role))fail('Company settings require owner or administrator access.',403);
   const name=String(body.name||'').trim();if(name.length<2||name.length>90)fail('Enter a company name (2–90 characters).');
   const settings:any={taxReserve:Number(body.taxReserve),loadShare:Number(body.loadShare)};
   settings.businessType=body.businessType||company.settings.businessType||'trucking';
   if(!['trucking','general','services','retail','projects'].includes(settings.businessType))fail('Choose a business type.');
   for(const key of ['entityType','region','fiscalYearEnd','businessDescription'])settings[key]=String(body[key]??company.settings[key]??'').trim().slice(0,key==='businessDescription'?1000:100);
   for(const key of ['monthlyRevenueGoal','monthlyExpenseBudget']){settings[key]=Number(body[key]??company.settings[key]??0);if(!Number.isFinite(settings[key])||settings[key]<0||settings[key]>1e9)fail('Enter a valid business budget.');}
   if(!Number.isFinite(settings.taxReserve)||settings.taxReserve<0||settings.taxReserve>60||!Number.isFinite(settings.loadShare)||settings.loadShare<0||settings.loadShare>100)fail('Enter valid percentages.');
   await checked(db.from('leos_companies').update({name,settings:{...company.settings,...settings}}).eq('id',cid));await audit(cid,user.id,'company.updated');return respond({ok:true});
  }
  if(action==='save_item'){
   const kind=body.kind;if(!KINDS.includes(kind)||!canWriteKind(role,kind))fail('Your role cannot edit this type of record.',403);
   const payload=cleanPayload(body.payload);let assigned=body.assignedTo||null;
   if(['driver','staff'].includes(role)&&['expense','fuel','fee'].includes(kind))payload.taxReview='needs_review';
   if(['income','contribution'].includes(kind))payload.status='paid';
   if(['invoice','bill'].includes(kind)&&payload.status==='paid')fail('Use Record payment to mark an invoice or bill paid.');
   if(payload.settlementId){
    const linked=await checked(db.from('leos_company_items').select('id').eq('company_id',cid).eq('id',uuid(payload.settlementId)).eq('kind','load').is('archived_at',null).maybeSingle());if(!linked)fail('Choose a load from this company.');
   }
   validateAssignment(role,user.id,assigned);
   if(['driver','staff'].includes(role))assigned=user.id;
   if(assigned){uuid(assigned);const m=await checked(db.from('leos_company_members').select('user_id').eq('company_id',cid).eq('user_id',assigned).maybeSingle());if(!m)fail('Assign a member of this company.');}
   const row:any={company_id:cid,kind,payload,assigned_to:assigned,updated_at:now()};
   if(body.id){
    const id=uuid(body.id);const old=await checked(db.from('leos_company_items').select('*').eq('company_id',cid).eq('id',id).is('archived_at',null).maybeSingle());
    if(!old)fail('Record not found.',404);if(old.kind!==kind)fail('A record type cannot be changed.');
    if(!canReadItem(role,user.id,old)||(['driver','staff'].includes(role)&&old.created_by!==user.id))fail('You cannot edit this record.',403);
    if(body.assignedTo===undefined&&!['driver','staff'].includes(role))row.assigned_to=old.assigned_to;
    if(old.payload.invoiceId||old.payload.billId||old.payload.sourceInvoiceId||old.payload.sourceBillId||old.payload.paymentConfirmedAt||(old.kind==='load'&&old.payload.status==='paid'))fail('Linked payment records are locked. Add a separate correcting record if needed.');
    if(['invoice','bill'].includes(old.kind)&&old.payload.status==='paid')fail('Paid invoices and bills are locked.');
    if(old.payload.appointmentId)payload.appointmentId=old.payload.appointmentId;
    if(kind==='load'&&payload.status==='paid')fail('Use Confirm payment to record a received load payment.');
    row.version=old.version+1;
    const changed=await checked(db.from('leos_company_items').update(row).eq('id',id).eq('company_id',cid).eq('version',body.version).select('id').maybeSingle());
    if(!changed)fail('Someone updated this record. Refresh and try again.',409);
    await audit(cid,user.id,'record.updated',{id,kind});return respond({id});
   }
   if(kind==='load'&&payload.status==='paid')fail('Complete delivery, then use Confirm payment.');
   row.created_by=user.id;row.id=uuid(body.newId);
   const existing=await checked(db.from('leos_company_items').select('id,created_by').eq('id',row.id).eq('company_id',cid).maybeSingle());
   if(existing){if(existing.created_by!==user.id)fail('Record identifier conflict.',409);return respond({id:existing.id});}
   const saved=await checked(db.from('leos_company_items').insert(row).select('id').single());await audit(cid,user.id,'record.created',{id:saved.id,kind});return respond(saved);
  }
  if(action==='record_installment'){
   if(!isManager(role)&&role!=='bookkeeper')fail('Financial access required.',403);
   const details=cleanPayload({description:'Payment',date:body.date});if(!details.date)fail('Choose actual payment date.');
   if(!Number.isInteger(Number(body.version))||Number(body.version)<1)fail('Refresh the record before payment.');
   const amount=Number(body.amount);if(typeof body.amount!=='number'||!Number.isFinite(amount)||amount<=0||amount>100000000||Math.abs(amount*100-Math.round(amount*100))>0.000001)fail('Enter a positive amount with at most two decimal places.');
   if(!['cash','card','bank_transfer','check','other'].includes(body.method)||!['payment','deposit'].includes(body.paymentType))fail('Choose payment method and type.');
   if(typeof body.reference!=='string'||body.reference.length>120)fail('Payment reference must be 120 characters or fewer.');
   return respond(await checked(db.rpc('leos_record_installment',{cid,item:uuid(body.id),actor:user.id,payment_date:details.date,expected_version:Number(body.version),method:body.method,reference:body.reference,payment_amount:amount,payment_id:uuid(body.paymentId),payment_type:body.paymentType})));
  }
  if(action==='confirm_payment'){
   if(!isManager(role)&&role!=='bookkeeper')fail('Financial access required.',403);
   const details=cleanPayload({description:'Payment',date:body.date});if(!details.date)fail('Choose the actual payment date.');
   if(!Number.isInteger(Number(body.version))||Number(body.version)<1)fail('Refresh the record before confirming payment.');
   if(!['cash','card','bank_transfer','check','other'].includes(body.method))fail('Choose the payment method.');
   if(typeof body.reference!=='string'||body.reference.length>120)fail('Payment reference must be 120 characters or fewer.');
   return respond(await checked(db.rpc('leos_confirm_payment',{cid,item:uuid(body.id),actor:user.id,payment_date:details.date,expected_version:Number(body.version),method:body.method,reference:body.reference})));
  }
  if(action==='invoice_appointment'){
   if(!isManager(role)&&role!=='bookkeeper')fail('Financial access required.',403);
   return respond({id:await checked(db.rpc('leos_invoice_appointment',{cid,appointment:uuid(body.id),actor:user.id}))});
  }
  if(action==='record_payment'){
   if(!isManager(role)&&role!=='bookkeeper')fail('A company owner, administrator or bookkeeper must record payments.',403);
   const details=cleanPayload({description:'Payment',date:body.date});if(!details.date)fail('Choose the payment date.');
   if(!Number.isInteger(Number(body.version))||Number(body.version)<1)fail('Refresh the record before recording payment.');
   const id=await checked(db.rpc('leos_record_business_payment',{cid,item:uuid(body.id),actor:user.id,payment_date:details.date,expected_version:Number(body.version)}));return respond({id});
  }
  if(action==='archive_item'){
   if(!isManager(role))fail('Only an owner or administrator can archive records.',403);
   const target=await checked(db.from('leos_company_items').select('payload,kind,version').eq('id',uuid(body.id)).eq('company_id',cid).maybeSingle());
   if(target&&(target.payload.invoiceId||target.payload.billId||target.payload.sourceInvoiceId||target.payload.sourceBillId||target.payload.paymentConfirmedAt||(target.kind==='load'&&target.payload.status==='paid')||(['invoice','bill'].includes(target.kind)&&target.payload.status==='paid')))fail('Paid invoices, bills and their payment entries remain linked. Add a correcting record instead of archiving.');
   if(!isManager(role))fail('Only an owner or administrator can archive records.',403);
   const item=await checked(db.from('leos_company_items').update({archived_at:now()}).eq('id',uuid(body.id)).eq('company_id',cid).eq('version',target?.version).is('archived_at',null).select('id').maybeSingle());if(!item)fail('Record not found.',404);
   await audit(cid,user.id,'record.archived',{id:body.id});return respond({ok:true});
  }
  if(action==='upload_file'){
   const file=form?.get('file');if(!(file instanceof File))fail('Choose a PDF or image.');
   if(file.size>10485760||file.size===0)fail('Choose a file under 10 MB.');
   const bytes=new Uint8Array(await file.arrayBuffer());if(!verifyFileSignature(bytes,file.type))fail('Use a valid PDF, JPG, PNG or WebP file.');
   let itemId=body.itemId||null;
   if(itemId){const item=await checked(db.from('leos_company_items').select('*').eq('company_id',cid).eq('id',uuid(itemId)).is('archived_at',null).maybeSingle());if(!item||!canReadItem(role,user.id,item)||!canWriteKind(role,item.kind))fail('Cannot attach to this record.',403);}
   const path=cid+'/'+crypto.randomUUID()+'/'+file.name.replace(/[^\w.-]/g,'_').slice(0,120);
   await checked(db.storage.from('leos-company-documents').upload(path,bytes,{contentType:file.type,upsert:false}));
   const saved=await checked(db.from('leos_company_files').insert({company_id:cid,item_id:itemId,uploaded_by:user.id,bucket:'leos-company-documents',path,name:file.name.slice(0,150),mime:file.type,size:file.size}).select('id').single());
   await audit(cid,user.id,'document.uploaded',{id:saved.id});return respond(saved);
  }
  if(action==='create_invite'){
   if(!isManager(role))fail('Team invitations require owner or administrator access.',403);
   const email=String(body.email||'').trim().toLowerCase(),invRole=body.role;
   if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254)fail('Enter a valid email address.');
   if(!ROLES.includes(invRole)||invRole==='owner'||(invRole==='admin'&&role!=='owner'))fail('Only the owner can invite administrators.',403);
   const pending=await db.from('leos_company_invites').select('*',{count:'exact',head:true}).eq('company_id',cid).is('accepted_at',null).is('revoked_at',null).gt('expires_at',now());if(pending.error)throw pending.error;if(pending.count!>=50)fail('Too many pending invitations. Revoke old invites first.');
   const raw=Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');
   const saved=await checked(db.from('leos_company_invites').insert({company_id:cid,email,role:invRole,token_hash:await sha(raw),created_by:user.id}).select('id').single());
   await audit(cid,user.id,'invite.created',{role:invRole});return respond({id:saved.id,url:APP+'/company.html#invite='+raw});
  }
  if(action==='revoke_invite'){
   if(!isManager(role))fail('Team access required.',403);
   const inv=await checked(db.from('leos_company_invites').select('role').eq('id',uuid(body.id)).eq('company_id',cid).maybeSingle());if(!inv||(inv.role==='admin'&&role!=='owner'))fail('Invitation not available.',403);
   await checked(db.from('leos_company_invites').update({revoked_at:now()}).eq('id',body.id).eq('company_id',cid));await audit(cid,user.id,'invite.revoked');return respond({ok:true});
  }
  if(action==='change_role'||action==='remove_member'){
   if(role!=='owner')fail('Only the owner can change team access.',403);
   const target=uuid(body.userId);if(target===user.id)fail('The company owner cannot be removed or demoted.');
   if(action==='change_role'){
    if(!ROLES.includes(body.role)||body.role==='owner')fail('Choose a team role.');
    await checked(db.from('leos_company_members').update({role:body.role}).eq('company_id',cid).eq('user_id',target));
   }else await checked(db.from('leos_company_members').delete().eq('company_id',cid).eq('user_id',target));
   await audit(cid,user.id,action==='change_role'?'member.role_changed':'member.removed',{userId:target});return respond({ok:true});
  }
  if(action==='import_legacy'){
   if(role!=='owner')fail('Only the owner can copy personal records into this company.',403);
   const legacy=await checked(db.from('leos_records').select('id,payload').eq('user_id',user.id).limit(10000));let copied=0;
   const personal=await checked(db.from('leos_settings').select('payload').eq('user_id',user.id).maybeSingle());
   const prefs=personal?.payload||{};
   for(const rec of legacy){
    if(!KINDS.includes(rec.payload?.kind))continue;
    const existing=await checked(db.from('leos_company_items').select('id').eq('company_id',cid).eq('legacy_user_id',user.id).eq('legacy_id',rec.id).maybeSingle());
    let itemId=existing?.id;
    if(!itemId){
     const payload={...rec.payload,...(rec.payload.kind==='load'?{payMode:prefs.payMode||'percent',payPerMile:prefs.payPerMile||0,loadShare:prefs.payMode==='gross'?100:Number(prefs.share??100)}:{})};
     const result=await db.from('leos_company_items').upsert({company_id:cid,kind:rec.payload.kind,payload,created_by:user.id,legacy_user_id:user.id,legacy_id:rec.id},{onConflict:'company_id,legacy_user_id,legacy_id',ignoreDuplicates:true}).select('id');if(result.error)throw result.error;
     itemId=result.data?.[0]?.id;if(itemId)copied++;
     if(!itemId)itemId=(await checked(db.from('leos_company_items').select('id').eq('company_id',cid).eq('legacy_user_id',user.id).eq('legacy_id',rec.id).single())).id;
    }
    // Link only objects actually owned by this authenticated user. Never expose their whole folder.
    for(const ref of rec.payload.photos||[]){
     if(typeof ref!=='string'||!ref.startsWith('supabase:'+user.id+'/'))continue;
     const path=ref.slice(9);
     // Storage schema is not exposed via PostgREST. A signed URL request verifies object existence privately instead.
     const signed=await db.storage.from('leos-receipts').createSignedUrl(path,1);if(signed.error)continue;
     await checked(db.from('leos_company_files').upsert({company_id:cid,item_id:itemId,uploaded_by:user.id,bucket:'leos-receipts',path,name:'Imported receipt — '+(rec.payload.description||rec.id).slice(0,90)},{onConflict:'company_id,bucket,path',ignoreDuplicates:true}));
    }
   }
   await audit(cid,user.id,'legacy.copied',{count:copied});return respond({copied,note:'Personal records and original receipt files are unchanged. Company copies are now separate.'});
  }
  fail('Unknown action.',404);
 }catch(error:any){
  const status=error.status||400;const message=error.status?error.message:(error.message?.includes('limit reached')?error.message:'The request could not be completed. Refresh and try again.');
  console.error('LEOS API request failed',error.code||status);return respond({error:message},status);
 }
}
Deno.serve(handler);
