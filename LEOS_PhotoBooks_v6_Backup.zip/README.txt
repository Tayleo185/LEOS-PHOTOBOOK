LEOS PhotoBooks 6.0 — One-file GitHub update

1. Download index.html from this folder (do NOT upload this README to your GitHub repo).
2. In https://github.com/Tayleo185/LEOS-PHOTOBOOK use Add file > Upload files.
3. Upload index.html to the REPOSITORY ROOT, replacing the previous index.html.
4. Commit changes to branch main.
5. Render's existing static site is configured to auto-deploy GitHub main commits.
6. On your phone reopen/refresh https://leos-photobooks.onrender.com. No app reinstall should be needed.

This v6 starter release:
- Adds a Routes tab with two manually entered commercial-truck-GPS alternatives,
  estimated fuel cost, tolls, savings and fuel-stop planning.
- Uses current saved load pickup/delivery addresses for route form autofill.
- Saves trip plans privately per signed-in account to public.leos_routes with RLS.
- Preserves Supabase accounting records and private receipt photos.
- Adds per-account company name and per-account truck dimensions.
- Removes another user's sample dispatch records from the public app code and new signups.
- Disables unsafely mixed local-device record imports in multi-user mode.

Limitations and safety:
- Not live commercial-truck navigation and not a truck-safe route certification.
- No live diesel-price, toll, bridge-clearance, or HOS data integration yet.
- Carrier/driver must verify truck route legality, road restrictions and load weights.
- Multiuser privacy is backed by Supabase Auth, row-level security and private buckets;
  production launch to unrelated customers still requires signup abuse controls,
  password-security settings, cross-account testing, and privacy/legal review.
- The route table and realtime publication are already applied to the existing Supabase project.

No new PDF or Excel files are required. GitHub needs index.html only.
