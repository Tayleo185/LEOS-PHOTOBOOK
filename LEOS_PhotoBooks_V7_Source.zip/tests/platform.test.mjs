import test from 'node:test';
import assert from 'node:assert/strict';
import {summarize,csv} from '../platform/domain.mjs';
import {canWriteKind,canReadItem,cleanPayload,writable,verifyFileSignature,validateAssignment} from '../supabase/functions/leos-platform/policy.mjs';
const row=(kind,payload)=>({kind,payload:{date:'2026-11-03',...payload}});
test('profit excludes settlements, draws, tax payments and scheduled loads',()=>{
 const result=summarize([row('load',{amount:1000,status:'completed',miles:500}),row('load',{amount:3000,status:'scheduled'}),row('expense',{amount:100}),row('fuel',{amount:200,credit:25,paidBy:'company'}),row('settlement',{amount:1000}),row('draw',{amount:400}),row('taxPayment',{amount:75})],{loadShare:88,taxReserve:25},'2026-11');
 assert.equal(result.revenue,880);assert.equal(result.expenses,300);assert.equal(result.credits,25);assert.equal(result.profit,605);assert.equal(result.unpaid,880);assert.equal(result.scheduled,2640);assert.equal(result.draws,400);assert.equal(result.taxReserve,151.25);
});
test('per-mile legacy loads retain their original pay calculation',()=>{
 const result=summarize([row('load',{amount:4000,miles:1200,status:'paid',payMode:'cpm',payPerMile:.8})],{loadShare:88});assert.equal(result.revenue,960);assert.equal(result.unpaid,0);
});
test('expense ownership retains legacy company and carrier meanings',()=>{
 const result=summarize([row('expense',{amount:10,paidBy:'company'}),row('fuel',{amount:20,paidBy:'carrier'}),row('expense',{amount:900,paidBy:'other'})]);assert.equal(result.expenses,30);
});
test('month filtering and losses do not produce a negative tax reserve',()=>{
 const result=summarize([row('expense',{amount:100}),{kind:'load',payload:{date:'2026-10-01',status:'paid',amount:2000}}],{},'2026-11');assert.equal(result.profit,-100);assert.equal(result.taxReserve,0);
});
test('driver and bookkeeping permissions protect company operations',()=>{
 assert.equal(canWriteKind('driver','load'),false);assert.equal(canWriteKind('driver','expense'),true);assert.equal(canWriteKind('driver','truck'),false);assert.equal(canWriteKind('dispatcher','draw'),false);assert.equal(canWriteKind('bookkeeper','truck'),false);assert.equal(canWriteKind('bookkeeper','settlement'),true);assert.equal(canWriteKind('owner','truck'),true);
 assert.equal(canReadItem('driver','alice',{created_by:'bob',assigned_to:'charlie'}),false);assert.equal(canReadItem('driver','alice',{created_by:'bob',assigned_to:'alice'}),true);assert.throws(()=>validateAssignment('driver','alice','bob'),/Drivers/);
});
test('unpaid or suspended companies cannot mutate records',()=>{
 assert.throws(()=>writable({subscription_status:'past_due'}),/read-only/);assert.throws(()=>writable({subscription_status:'active',suspended:true}),/suspended/);assert.doesNotThrow(()=>writable({subscription_status:'preview'}));
});
test('server validation rejects invalid money and unapproved record properties',()=>{
 assert.throws(()=>cleanPayload({description:'Fuel',amount:-5}),/valid amount/);assert.throws(()=>cleanPayload({description:'Load',loadShare:150}),/between/);assert.throws(()=>cleanPayload({description:'Load',payMode:'arbitrary'}),/pay calculation/);
 assert.deepEqual(cleanPayload({description:'  Fuel ',amount:'12.34',company_id:'other',role:'owner',odometer:'100'}),{description:'Fuel',amount:12.34,odometer:100});
 assert.throws(()=>cleanPayload({description:'Test',date:'2026-02-31'}),/valid date/);
});
test('file contents must match the allowed type',()=>{
 assert.equal(verifyFileSignature(new Uint8Array([37,80,68,70,45]),'application/pdf'),true);assert.equal(verifyFileSignature(new TextEncoder().encode('<script>'),'image/jpeg'),false);assert.equal(verifyFileSignature(new Uint8Array([255,216,255]),'text/html'),false);
});
test('CSV export escapes delimiters and spreadsheet formulas',()=>{assert.equal(csv([['=HYPERLINK("bad")','a,b','line\n2']]),'"\'=HYPERLINK(""bad"")","a,b","line\n2"');});
