-- Disposable fixtures. Every fixture is rolled back, including Auth rows.
begin;
insert into auth.users(id,email) values
 ('11111111-1111-4111-8111-111111111111','leos-test-owner-a@example.invalid'),
 ('22222222-2222-4222-8222-222222222222','leos-test-driver-a@example.invalid'),
 ('33333333-3333-4333-8333-333333333333','leos-test-owner-b@example.invalid');
set local role service_role;
insert into public.leos_companies(id,name,created_by) values
 ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','Isolation Test A','11111111-1111-4111-8111-111111111111'),
 ('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','Isolation Test B','33333333-3333-4333-8333-333333333333');
insert into public.leos_company_members(company_id,user_id,role,email) values('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','22222222-2222-4222-8222-222222222222','driver','leos-test-driver-a@example.invalid');
insert into public.leos_company_items(id,company_id,kind,created_by,assigned_to,payload) values
 ('aaaaaaaa-1111-4111-8111-111111111111','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','load','11111111-1111-4111-8111-111111111111',null,'{"description":"Hidden from driver"}'),
 ('aaaaaaaa-2222-4222-8222-222222222222','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','load','11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222','{"description":"Assigned to driver"}'),
 ('bbbbbbbb-1111-4111-8111-111111111111','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','load','33333333-3333-4333-8333-333333333333',null,'{"description":"Company B private"}');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"11111111-1111-4111-8111-111111111111","role":"authenticated"}',true);
do $$ begin
 if (select count(*) from public.leos_companies)<>1 then raise exception 'FAIL: owner company isolation'; end if;
 if (select count(*) from public.leos_company_items)<>2 then raise exception 'FAIL: owner record isolation'; end if;
 if has_table_privilege('authenticated','public.leos_companies','UPDATE') then raise exception 'FAIL: client can alter billing'; end if;
 if has_function_privilege('authenticated','public.leos_accept_company_invite(text,uuid,text)','EXECUTE') then raise exception 'FAIL: invite bypass exposed'; end if;
end $$;
select set_config('request.jwt.claims','{"sub":"22222222-2222-4222-8222-222222222222","role":"authenticated"}',true);
do $$ begin
 if (select count(*) from public.leos_company_items)<>1 then raise exception 'FAIL: driver assignment isolation'; end if;
 if not exists(select 1 from public.leos_company_items where id='aaaaaaaa-2222-4222-8222-222222222222') then raise exception 'FAIL: assigned load unavailable'; end if;
end $$;
set local role service_role;
delete from public.leos_company_members where company_id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa' and user_id='22222222-2222-4222-8222-222222222222';
set local role authenticated;
do $$ begin
 if (select count(*) from public.leos_company_items)<>0 then raise exception 'FAIL: removed member still has record access'; end if;
 if (select count(*) from public.leos_companies)<>0 then raise exception 'FAIL: removed member still has company access'; end if;
end $$;
rollback;
select 'PASS: company isolation, driver assignment, removed-member access, billing protection, invite RPC privileges. Test fixtures rolled back.' as result;
